-- AlterTable: Add abandoned order recovery tracking columns
ALTER TABLE "CodOrder" ADD COLUMN "recoveryAttempts" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "CodOrder" ADD COLUMN "lastRecoveryAt" TIMESTAMP(3);
ALTER TABLE "CodOrder" ADD COLUMN "customerEmail" TEXT;
