import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import {
  Page, Layout, Card, Text, BlockStack, InlineGrid, Select, Box, Divider, InlineStack,
} from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import { prisma } from "../db.server";
import { useState } from "react";

export async function loader({ request }) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;

  const now = new Date();
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  const [
    totalOrders, confirmedOrders, cancelledOrders, fakeOrders,
    last30Orders, last7Orders, revenueData, topForms,
  ] = await Promise.all([
    prisma.codOrder.count({ where: { shop } }),
    prisma.codOrder.count({ where: { shop, status: "confirmed" } }),
    prisma.codOrder.count({ where: { shop, status: "cancelled" } }),
    prisma.codOrder.count({ where: { shop, isFake: true } }),
    prisma.codOrder.count({ where: { shop, createdAt: { gte: thirtyDaysAgo } } }),
    prisma.codOrder.count({ where: { shop, createdAt: { gte: sevenDaysAgo } } }),
    prisma.codOrder.aggregate({
      where: { shop, status: { not: "cancelled" } },
      _sum: { totalAmount: true },
      _avg: { totalAmount: true },
    }),
    prisma.codOrder.groupBy({
      by: ["formId"],
      where: { shop, formId: { not: null } },
      _count: { id: true },
      orderBy: { _count: { id: "desc" } },
      take: 5,
    }),
  ]);

  // Daily breakdown for last 7 days
  const dailyOrders = [];
  for (let i = 6; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const start = new Date(date.setHours(0, 0, 0, 0));
    const end = new Date(date.setHours(23, 59, 59, 999));
    const count = await prisma.codOrder.count({
      where: { shop, createdAt: { gte: start, lte: end } },
    });
    const revenue = await prisma.codOrder.aggregate({
      where: { shop, createdAt: { gte: start, lte: end }, status: { not: "cancelled" } },
      _sum: { totalAmount: true },
    });
    dailyOrders.push({
      date: start.toLocaleDateString("en-IN", { weekday: "short", day: "numeric" }),
      orders: count,
      revenue: revenue._sum.totalAmount || 0,
    });
  }

  const conversionRate = totalOrders > 0
    ? ((confirmedOrders / totalOrders) * 100).toFixed(1)
    : 0;

  return json({
    stats: {
      totalOrders,
      confirmedOrders,
      cancelledOrders,
      fakeOrders,
      last30Orders,
      last7Orders,
      revenue: revenueData._sum.totalAmount || 0,
      avgOrderValue: revenueData._avg.totalAmount || 0,
      conversionRate,
    },
    dailyOrders,
    topForms,
  });
}

export default function AnalyticsPage() {
  const { stats, dailyOrders, topForms } = useLoaderData();

  const maxOrders = Math.max(...dailyOrders.map((d) => d.orders), 1);
  const maxRevenue = Math.max(...dailyOrders.map((d) => d.revenue), 1);

  return (
    <Page title="Analytics & Reports">
      <BlockStack gap="500">
        {/* KPI Cards */}
        <InlineGrid columns={4} gap="400">
          {[
            { label: "Total Orders", value: stats.totalOrders, color: "#FF6B00" },
            { label: "Confirmed", value: stats.confirmedOrders, color: "#00A36C" },
            { label: "Conversion Rate", value: `${stats.conversionRate}%`, color: "#8B5CF6" },
            { label: "Total Revenue", value: `₹${stats.revenue.toLocaleString("en-IN")}`, color: "#0EA5E9" },
            { label: "Avg Order Value", value: `₹${Math.round(stats.avgOrderValue)}`, color: "#F59E0B" },
            { label: "Last 7 Days", value: stats.last7Orders, color: "#EC4899" },
            { label: "Last 30 Days", value: stats.last30Orders, color: "#14B8A6" },
            { label: "Fake Orders", value: stats.fakeOrders, color: "#EF4444" },
          ].map((kpi) => (
            <Card key={kpi.label}>
              <BlockStack gap="200">
                <Text variant="bodySm" tone="subdued">{kpi.label}</Text>
                <Text variant="headingXl" as="p" fontWeight="bold">
                  <span style={{ color: kpi.color }}>{kpi.value}</span>
                </Text>
              </BlockStack>
            </Card>
          ))}
        </InlineGrid>

        <Layout>
          <Layout.Section>
            <Card>
              <BlockStack gap="400">
                <Text variant="headingMd">Orders – Last 7 Days</Text>
                {/* Simple bar chart using divs */}
                <div style={{ display: "flex", alignItems: "flex-end", gap: 8, height: 160 }}>
                  {dailyOrders.map((day) => (
                    <div
                      key={day.date}
                      style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}
                    >
                      <Text variant="bodySm">{day.orders}</Text>
                      <div
                        style={{
                          width: "100%",
                          height: `${(day.orders / maxOrders) * 120}px`,
                          backgroundColor: "#FF6B00",
                          borderRadius: "4px 4px 0 0",
                          minHeight: 4,
                          transition: "height 0.3s ease",
                        }}
                      />
                      <Text variant="bodySm" tone="subdued">{day.date}</Text>
                    </div>
                  ))}
                </div>
              </BlockStack>
            </Card>
          </Layout.Section>

          <Layout.Section>
            <Card>
              <BlockStack gap="400">
                <Text variant="headingMd">Revenue – Last 7 Days (₹)</Text>
                <div style={{ display: "flex", alignItems: "flex-end", gap: 8, height: 160 }}>
                  {dailyOrders.map((day) => (
                    <div
                      key={day.date}
                      style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}
                    >
                      <Text variant="bodySm">₹{Math.round(day.revenue)}</Text>
                      <div
                        style={{
                          width: "100%",
                          height: `${(day.revenue / maxRevenue) * 120}px`,
                          backgroundColor: "#8B5CF6",
                          borderRadius: "4px 4px 0 0",
                          minHeight: 4,
                        }}
                      />
                      <Text variant="bodySm" tone="subdued">{day.date}</Text>
                    </div>
                  ))}
                </div>
              </BlockStack>
            </Card>
          </Layout.Section>
        </Layout>

        {/* Order Status Breakdown */}
        <Card>
          <BlockStack gap="300">
            <Text variant="headingMd">Order Status Breakdown</Text>
            <Divider />
            <InlineGrid columns={5} gap="400">
              {[
                { label: "Pending", count: stats.totalOrders - stats.confirmedOrders - stats.cancelledOrders, color: "#0EA5E9" },
                { label: "Confirmed", count: stats.confirmedOrders, color: "#00A36C" },
                { label: "Cancelled", count: stats.cancelledOrders, color: "#EF4444" },
                { label: "Fake", count: stats.fakeOrders, color: "#F59E0B" },
              ].map((item) => (
                <Box key={item.label} padding="300" background="bg-surface-secondary" borderRadius="200">
                  <BlockStack gap="100" inlineAlign="center">
                    <div
                      style={{
                        width: 12,
                        height: 12,
                        borderRadius: "50%",
                        backgroundColor: item.color,
                        margin: "0 auto",
                      }}
                    />
                    <Text alignment="center" fontWeight="bold">{item.count}</Text>
                    <Text alignment="center" tone="subdued" variant="bodySm">{item.label}</Text>
                  </BlockStack>
                </Box>
              ))}
            </InlineGrid>
          </BlockStack>
        </Card>
      </BlockStack>
    </Page>
  );
}
