import { json, redirect } from "@remix-run/node";
import { useLoaderData, useSubmit, useNavigation } from "@remix-run/react";
import {
  Page, Layout, Card, TextField, Checkbox, Select, Button,
  BlockStack, FormLayout, Text, Divider, Banner, Tabs, Box, Badge,
} from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import { prisma } from "../db.server";
import { useState } from "react";

export async function loader({ request }) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  let store = await prisma.store.findUnique({ where: { shop } });
  if (!store) {
    store = await prisma.store.create({ data: { shop } });
  }
  return json({ store });
}

export async function action({ request }) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const body = await request.json();

  await prisma.store.upsert({
    where: { shop },
    create: { shop, ...body },
    update: body,
  });

  return json({ success: true });
}

export default function SettingsPage() {
  const { store } = useLoaderData();
  const submit = useSubmit();
  const navigation = useNavigation();
  const isSaving = navigation.state === "submitting";
  const [selectedTab, setSelectedTab] = useState(0);

  const [settings, setSettings] = useState({
    // WhatsApp
    whatsappEnabled: store.whatsappEnabled || false,
    whatsappNumber: store.whatsappNumber || "",
    // SMS
    smsEnabled: store.smsEnabled || false,
    otpApiKey: store.otpApiKey || "",
    otpProvider: store.otpProvider || "twilio",
    // Email
    emailEnabled: store.emailEnabled || false,
    emailFrom: store.emailFrom || "",
    emailSmtpHost: store.emailSmtpHost || "",
    emailSmtpPort: store.emailSmtpPort || 587,
    emailSmtpUser: store.emailSmtpUser || "",
    emailSmtpPass: store.emailSmtpPass || "",
    // OTP
    otpEnabled: store.otpEnabled || false,
    // Pixels
    fbPixelId: store.fbPixelId || "",
    tiktokPixelId: store.tiktokPixelId || "",
    gaTrackingId: store.gaTrackingId || "",
    // Google Sheets
    googleSheetsId: store.googleSheetsId || "",
    googleSheetsCredentials: store.googleSheetsCredentials || "",
    // Fake order
    fakeOrderDetection: store.fakeOrderDetection !== false,
    blockedPhones: (store.blockedPhones || []).join(", "),
    blockedEmails: (store.blockedEmails || []).join(", "),
  });

  const update = (key, value) => setSettings((s) => ({ ...s, [key]: value }));

  const handleSave = () => {
    const payload = {
      ...settings,
      blockedPhones: settings.blockedPhones.split(",").map((s) => s.trim()).filter(Boolean),
      blockedEmails: settings.blockedEmails.split(",").map((s) => s.trim()).filter(Boolean),
      emailSmtpPort: parseInt(settings.emailSmtpPort),
    };
    submit(payload, { method: "post", encType: "application/json" });
  };

  const tabs = [
    { id: "whatsapp", content: "WhatsApp" },
    { id: "sms", content: "SMS / OTP" },
    { id: "email", content: "Email" },
    { id: "pixels", content: "Pixels & Tracking" },
    { id: "sheets", content: "Google Sheets" },
    { id: "security", content: "Security" },
  ];

  return (
    <Page
      title="Settings"
      primaryAction={{
        content: isSaving ? "Saving..." : "Save Settings",
        onAction: handleSave,
        loading: isSaving,
      }}
    >
      <Layout>
        <Layout.Section>
          <Card>
            <Tabs tabs={tabs} selected={selectedTab} onSelect={setSelectedTab}>
              <Box padding="400">
                {/* WhatsApp */}
                {selectedTab === 0 && (
                  <FormLayout>
                    <Banner tone="info">
                      Send automatic WhatsApp messages to customers when an order is placed.
                      Requires a WhatsApp Business API provider.
                    </Banner>
                    <Checkbox
                      label="Enable WhatsApp Notifications"
                      checked={settings.whatsappEnabled}
                      onChange={(v) => update("whatsappEnabled", v)}
                    />
                    {settings.whatsappEnabled && (
                      <TextField
                        label="WhatsApp Business Number"
                        value={settings.whatsappNumber}
                        onChange={(v) => update("whatsappNumber", v)}
                        placeholder="+91XXXXXXXXXX"
                        helpText="Include country code. Used as the sender number."
                      />
                    )}
                  </FormLayout>
                )}

                {/* SMS / OTP */}
                {selectedTab === 1 && (
                  <FormLayout>
                    <Checkbox
                      label="Enable OTP Verification"
                      checked={settings.otpEnabled}
                      onChange={(v) => update("otpEnabled", v)}
                    />
                    {settings.otpEnabled && (
                      <>
                        <Select
                          label="OTP Provider"
                          options={[
                            { label: "Twilio", value: "twilio" },
                            { label: "MSG91", value: "msg91" },
                            { label: "Fast2SMS", value: "fast2sms" },
                          ]}
                          value={settings.otpProvider}
                          onChange={(v) => update("otpProvider", v)}
                        />
                        <TextField
                          label="API Key / Auth Token"
                          value={settings.otpApiKey}
                          onChange={(v) => update("otpApiKey", v)}
                          type="password"
                        />
                      </>
                    )}
                    <Divider />
                    <Checkbox
                      label="Enable SMS Notifications (order confirmation)"
                      checked={settings.smsEnabled}
                      onChange={(v) => update("smsEnabled", v)}
                    />
                  </FormLayout>
                )}

                {/* Email */}
                {selectedTab === 2 && (
                  <FormLayout>
                    <Checkbox
                      label="Enable Email Notifications"
                      checked={settings.emailEnabled}
                      onChange={(v) => update("emailEnabled", v)}
                    />
                    {settings.emailEnabled && (
                      <>
                        <TextField
                          label="From Email"
                          value={settings.emailFrom}
                          onChange={(v) => update("emailFrom", v)}
                          placeholder="orders@yourstore.com"
                        />
                        <TextField
                          label="SMTP Host"
                          value={settings.emailSmtpHost}
                          onChange={(v) => update("emailSmtpHost", v)}
                          placeholder="smtp.gmail.com"
                        />
                        <TextField
                          label="SMTP Port"
                          type="number"
                          value={String(settings.emailSmtpPort)}
                          onChange={(v) => update("emailSmtpPort", v)}
                        />
                        <TextField
                          label="SMTP Username"
                          value={settings.emailSmtpUser}
                          onChange={(v) => update("emailSmtpUser", v)}
                        />
                        <TextField
                          label="SMTP Password"
                          value={settings.emailSmtpPass}
                          onChange={(v) => update("emailSmtpPass", v)}
                          type="password"
                        />
                      </>
                    )}
                  </FormLayout>
                )}

                {/* Pixels */}
                {selectedTab === 3 && (
                  <FormLayout>
                    <Banner tone="info">
                      Pixels fire automatically on every successful COD order submission.
                    </Banner>
                    <TextField
                      label="Facebook Pixel ID"
                      value={settings.fbPixelId}
                      onChange={(v) => update("fbPixelId", v)}
                      placeholder="123456789012345"
                      helpText="Fires Purchase event on order submission"
                    />
                    <TextField
                      label="TikTok Pixel ID"
                      value={settings.tiktokPixelId}
                      onChange={(v) => update("tiktokPixelId", v)}
                      placeholder="CXXXXXXXXXXXXXXXXX"
                    />
                    <TextField
                      label="Google Analytics Tracking ID"
                      value={settings.gaTrackingId}
                      onChange={(v) => update("gaTrackingId", v)}
                      placeholder="G-XXXXXXXXXX or UA-XXXXXX-X"
                    />
                  </FormLayout>
                )}

                {/* Google Sheets */}
                {selectedTab === 4 && (
                  <FormLayout>
                    <Banner tone="info">
                      Every COD order will be automatically logged to your Google Sheet.
                      You'll need a Google Service Account JSON key.
                    </Banner>
                    <TextField
                      label="Google Sheet ID"
                      value={settings.googleSheetsId}
                      onChange={(v) => update("googleSheetsId", v)}
                      placeholder="1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms"
                      helpText="The long ID from your Google Sheets URL"
                    />
                    <TextField
                      label="Service Account Credentials (JSON)"
                      value={settings.googleSheetsCredentials}
                      onChange={(v) => update("googleSheetsCredentials", v)}
                      multiline={6}
                      placeholder='{"type":"service_account","project_id":"...","private_key":"..."}'
                    />
                  </FormLayout>
                )}

                {/* Security */}
                {selectedTab === 5 && (
                  <FormLayout>
                    <Checkbox
                      label="Enable Fake Order Detection"
                      checked={settings.fakeOrderDetection}
                      onChange={(v) => update("fakeOrderDetection", v)}
                    />
                    <Banner tone="info">
                      Fake order detection flags orders from repeated failed OTPs,
                      known spam patterns, and your blocked list below.
                    </Banner>
                    <TextField
                      label="Blocked Phone Numbers"
                      value={settings.blockedPhones}
                      onChange={(v) => update("blockedPhones", v)}
                      multiline={3}
                      placeholder="9999999999, 8888888888"
                      helpText="Comma-separated phone numbers to block"
                    />
                    <TextField
                      label="Blocked Email Addresses"
                      value={settings.blockedEmails}
                      onChange={(v) => update("blockedEmails", v)}
                      multiline={3}
                      placeholder="spam@example.com, fake@test.com"
                      helpText="Comma-separated emails to block"
                    />
                  </FormLayout>
                )}
              </Box>
            </Tabs>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
