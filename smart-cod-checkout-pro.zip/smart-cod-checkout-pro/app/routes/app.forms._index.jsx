import { json, redirect } from "@remix-run/node";
import { useLoaderData, useSubmit } from "@remix-run/react";
import {
  Page,
  Card,
  IndexTable,
  Badge,
  Button,
  Text,
  BlockStack,
  EmptyState,
  InlineStack,
  Thumbnail,
  useIndexResourceState,
  Toast,
  Frame,
} from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import { prisma } from "../db.server";
import { useState } from "react";

export async function loader({ request }) {
  const { session } = await authenticate.admin(request);
  const forms = await prisma.codForm.findMany({
    where: { shop: session.shop },
    orderBy: { createdAt: "desc" },
  });
  return json({ forms });
}

export async function action({ request }) {
  const { session } = await authenticate.admin(request);
  const formData = await request.formData();
  const intent = formData.get("intent");
  const formId = formData.get("formId");

  if (intent === "delete") {
    await prisma.codForm.delete({
      where: { id: formId, shop: session.shop },
    });
    return json({ success: true, message: "Form deleted" });
  }

  if (intent === "toggle") {
    const form = await prisma.codForm.findUnique({ where: { id: formId } });
    await prisma.codForm.update({
      where: { id: formId },
      data: { isActive: !form.isActive },
    });
    return json({ success: true });
  }

  if (intent === "duplicate") {
    const original = await prisma.codForm.findUnique({ where: { id: formId } });
    const { id, createdAt, updatedAt, ...rest } = original;
    await prisma.codForm.create({
      data: {
        ...rest,
        name: `${rest.name} (Copy)`,
        slug: `${rest.slug}-copy-${Date.now()}`,
        isDefault: false,
      },
    });
    return json({ success: true, message: "Form duplicated" });
  }

  return json({ error: "Unknown intent" }, { status: 400 });
}

export default function FormsPage() {
  const { forms } = useLoaderData();
  const submit = useSubmit();
  const [toastMessage, setToastMessage] = useState(null);

  const { selectedResources, allResourcesSelected, handleSelectionChange } =
    useIndexResourceState(forms);

  const resourceName = { singular: "form", plural: "forms" };

  const rowMarkup = forms.map(
    ({ id, name, layout, template, isActive, isDefault, orders, createdAt }, index) => (
      <IndexTable.Row
        id={id}
        key={id}
        selected={selectedResources.includes(id)}
        position={index}
      >
        <IndexTable.Cell>
          <Text variant="bodyMd" fontWeight="bold">
            {name}
          </Text>
          {isDefault && <Badge>Default</Badge>}
        </IndexTable.Cell>
        <IndexTable.Cell>
          <Badge>{layout}</Badge>
        </IndexTable.Cell>
        <IndexTable.Cell>
          <Badge>{template}</Badge>
        </IndexTable.Cell>
        <IndexTable.Cell>
          <Badge tone={isActive ? "success" : "critical"}>
            {isActive ? "Active" : "Inactive"}
          </Badge>
        </IndexTable.Cell>
        <IndexTable.Cell>
          {new Date(createdAt).toLocaleDateString("en-IN")}
        </IndexTable.Cell>
        <IndexTable.Cell>
          <InlineStack gap="200">
            <Button url={`/app/forms/${id}`} variant="plain">Edit</Button>
            <Button
              variant="plain"
              onClick={() => {
                submit(
                  { intent: "duplicate", formId: id },
                  { method: "post" }
                );
              }}
            >
              Duplicate
            </Button>
            <Button
              variant="plain"
              tone="critical"
              onClick={() => {
                if (confirm("Delete this form?")) {
                  submit({ intent: "delete", formId: id }, { method: "post" });
                }
              }}
            >
              Delete
            </Button>
          </InlineStack>
        </IndexTable.Cell>
      </IndexTable.Row>
    )
  );

  return (
    <Frame>
      <Page
        title="COD Forms"
        primaryAction={
          <Button variant="primary" url="/app/forms/new">
            Create New Form
          </Button>
        }
      >
        <Card>
          {forms.length === 0 ? (
            <EmptyState
              heading="Create your first COD form"
              image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
              action={{ content: "Create Form", url: "/app/forms/new" }}
            >
              <p>
                Replace Shopify's default checkout with a lightning-fast COD
                form to boost conversions.
              </p>
            </EmptyState>
          ) : (
            <IndexTable
              resourceName={resourceName}
              itemCount={forms.length}
              selectedItemsCount={
                allResourcesSelected ? "All" : selectedResources.length
              }
              onSelectionChange={handleSelectionChange}
              headings={[
                { title: "Form Name" },
                { title: "Layout" },
                { title: "Template" },
                { title: "Status" },
                { title: "Created" },
                { title: "Actions" },
              ]}
            >
              {rowMarkup}
            </IndexTable>
          )}
        </Card>
      </Page>
      {toastMessage && (
        <Toast content={toastMessage} onDismiss={() => setToastMessage(null)} />
      )}
    </Frame>
  );
}
