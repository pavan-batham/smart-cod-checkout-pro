import { json } from "@remix-run/node";
import { prisma } from "../db.server";
import { sendNotifications } from "../utils/notifications.server";
import { syncToGoogleSheets } from "../utils/sheets.server";
import { createShopifyOrder } from "../utils/shopifyOrder.server";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export async function loader() {
  return new Response(null, { headers: corsHeaders });
}

export async function action({ request }) {
  if (request.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { orderId, otp } = await request.json();

    if (!orderId || !otp) {
      return json(
        { success: false, error: "Missing orderId or OTP" },
        { status: 400, headers: corsHeaders }
      );
    }

    const order = await prisma.codOrder.findUnique({ where: { id: orderId } });
    if (!order) {
      return json(
        { success: false, error: "Order not found" },
        { status: 404, headers: corsHeaders }
      );
    }

    if (order.otpVerified) {
      return json(
        { success: true, message: "Already verified" },
        { headers: corsHeaders }
      );
    }

    if (!order.otpCode || !order.otpExpiresAt) {
      return json(
        { success: false, error: "No OTP found for this order" },
        { status: 400, headers: corsHeaders }
      );
    }

    if (new Date() > new Date(order.otpExpiresAt)) {
      return json(
        { success: false, error: "OTP has expired. Please request a new one." },
        { status: 400, headers: corsHeaders }
      );
    }

    if (order.otpCode !== String(otp).trim()) {
      return json(
        { success: false, error: "Incorrect OTP. Please try again." },
        { status: 400, headers: corsHeaders }
      );
    }

    // OTP verified — update order
    await prisma.codOrder.update({
      where: { id: orderId },
      data: {
        otpVerified: true,
        status: "confirmed",
      },
    });

    const store = await prisma.store.findUnique({ where: { shop: order.shop } });
    const form = order.formId
      ? await prisma.codForm.findUnique({ where: { id: order.formId } })
      : null;

    // Create Shopify order
    try {
      const shopifyOrder = await createShopifyOrder({ shop: order.shop, order });
      if (shopifyOrder) {
        await prisma.codOrder.update({
          where: { id: orderId },
          data: {
            shopifyOrderId: shopifyOrder.id,
            shopifyOrderNumber: shopifyOrder.name,
          },
        });
      }
    } catch (err) {
      console.error("Shopify sync after OTP:", err);
    }

    // Send notifications
    if (store) {
      sendNotifications({ order, store }).catch(console.error);
      if (store.googleSheetsId) {
        syncToGoogleSheets({ order, store }).catch(console.error);
      }
    }

    return json(
      {
        success: true,
        message: form?.successMessage || "Order confirmed! We'll contact you shortly.",
        redirect: form?.thankYouRedirect || null,
      },
      { headers: corsHeaders }
    );
  } catch (err) {
    console.error("OTP verification error:", err);
    return json(
      { success: false, error: "Verification failed. Please try again." },
      { status: 500, headers: corsHeaders }
    );
  }
}
