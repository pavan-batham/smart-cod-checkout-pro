import { db } from "../db.server.js";

export async function loader() {
  try {
    // Quick DB ping
    await db.$queryRaw`SELECT 1`;
    return new Response(
      JSON.stringify({ status: "ok", timestamp: new Date().toISOString() }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ status: "error", error: err.message }),
      { status: 503, headers: { "Content-Type": "application/json" } }
    );
  }
}
