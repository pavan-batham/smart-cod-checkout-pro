import { json } from "@remix-run/node";
import { prisma } from "../db.server";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export async function loader({ request }) {
  const url = new URL(request.url);
  const shop = url.searchParams.get("shop");
  const formId = url.searchParams.get("formId");
  const productId = url.searchParams.get("productId");

  if (!shop) {
    return json({ error: "shop required" }, { status: 400, headers: corsHeaders });
  }

  let form;
  if (formId) {
    form = await prisma.codForm.findUnique({
      where: { id: formId, shop, isActive: true },
    });
  } else if (productId) {
    // Find form targeting this product
    form = await prisma.codForm.findFirst({
      where: {
        shop,
        isActive: true,
        OR: [
          { allProducts: true },
          { productIds: { has: productId } },
        ],
      },
      orderBy: { isDefault: "desc" },
    });
  }

  if (!form) {
    // Fallback to default form
    form = await prisma.codForm.findFirst({
      where: { shop, isActive: true, isDefault: true },
    });
  }

  if (!form) {
    return json({ form: null }, { headers: corsHeaders });
  }

  const store = await prisma.store.findUnique({ where: { shop } });

  return json(
    {
      form: {
        id: form.id,
        layout: form.layout,
        template: form.template,
        triggerType: form.triggerType,
        btnText: form.btnText,
        btnBgColor: form.btnBgColor,
        btnTextColor: form.btnTextColor,
        btnBorderRadius: form.btnBorderRadius,
        btnFontSize: form.btnFontSize,
        btnFullWidth: form.btnFullWidth,
        showCartIcon: form.showCartIcon,
        formTitle: form.formTitle,
        formBgColor: form.formBgColor,
        formTextColor: form.formTextColor,
        accentColor: form.accentColor,
        fontFamily: form.fontFamily,
        customCss: form.customCss,
        logoUrl: form.logoUrl,
        brandName: form.brandName,
        fields: form.fields,
        discountEnabled: form.discountEnabled,
        discountCode: form.discountCode,
        discountType: form.discountType,
        discountValue: form.discountValue,
        showQuantity: form.showQuantity,
        minQuantity: form.minQuantity,
        maxQuantity: form.maxQuantity,
        trustBadges: form.trustBadges,
        urgencyText: form.urgencyText,
        successMessage: form.successMessage,
        thankYouRedirect: form.thankYouRedirect,
      },
      tracking: {
        fbPixelId: store?.fbPixelId,
        tiktokPixelId: store?.tiktokPixelId,
        gaTrackingId: store?.gaTrackingId,
        otpEnabled: store?.otpEnabled,
      },
      appUrl: process.env.SHOPIFY_APP_URL,
    },
    { headers: corsHeaders }
  );
}
