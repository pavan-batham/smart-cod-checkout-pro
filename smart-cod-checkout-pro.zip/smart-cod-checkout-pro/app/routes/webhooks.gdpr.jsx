/**
 * GDPR Webhooks — Required for Shopify App Store submission
 * Handles: customers/data_request, customers/redact, shop/redact
 */

import { authenticate } from "../shopify.server.js";
import { db } from "../db.server.js";

export async function action({ request }) {
  const { topic, shop, session, payload } = await authenticate.webhook(request);

  console.log(`[GDPR Webhook] topic=${topic} shop=${shop}`);

  switch (topic) {
    case "CUSTOMERS_DATA_REQUEST":
      return handleCustomersDataRequest(shop, payload);

    case "CUSTOMERS_REDACT":
      return handleCustomersRedact(shop, payload);

    case "SHOP_REDACT":
      return handleShopRedact(shop);

    default:
      return new Response("Unhandled GDPR topic", { status: 422 });
  }
}

/**
 * Merchant requests all data stored for a customer.
 * In production: email a report to the merchant's data_request.email
 */
async function handleCustomersDataRequest(shop, payload) {
  const { customer, data_request } = payload;

  const orders = await db.codOrder.findMany({
    where: {
      store: { shopDomain: shop },
      OR: [
        { customerPhone: customer.phone },
        { customerEmail: customer.email },
      ],
    },
    select: {
      id: true,
      customerName: true,
      customerPhone: true,
      customerEmail: true,
      shippingAddress: true,
      createdAt: true,
      status: true,
      totalAmount: true,
      productTitle: true,
    },
  });

  // Log the data request — in production, email this to data_request.email
  console.log(`[GDPR] Data request for customer ${customer.id} at ${shop}`);
  console.log(`[GDPR] Found ${orders.length} COD orders`);
  console.log(`[GDPR] Report should be sent to: ${data_request?.email}`);

  return new Response("Customer data request received", { status: 200 });
}

/**
 * Merchant requests deletion of a customer's personal data.
 * Anonymizes PII from COD orders.
 */
async function handleCustomersRedact(shop, payload) {
  const { customer } = payload;

  const store = await db.store.findUnique({ where: { shopDomain: shop } });
  if (!store) return new Response("Store not found", { status: 200 });

  // Anonymize PII — keep order records but remove personal data
  const updated = await db.codOrder.updateMany({
    where: {
      storeId: store.id,
      OR: [
        { customerPhone: customer.phone },
        { customerEmail: customer.email },
      ],
    },
    data: {
      customerName: "[REDACTED]",
      customerPhone: "[REDACTED]",
      customerEmail: null,
      shippingAddress: "[REDACTED]",
    },
  });

  console.log(`[GDPR] Redacted ${updated.count} orders for customer ${customer.id} at ${shop}`);
  return new Response("Customer data redacted", { status: 200 });
}

/**
 * Shop uninstalled — delete all store data after 48h grace period.
 * In production, schedule this via a job queue.
 */
async function handleShopRedact(shop) {
  const store = await db.store.findUnique({ where: { shopDomain: shop } });

  if (store) {
    // Delete all related data
    await db.analyticsEvent.deleteMany({ where: { storeId: store.id } });
    await db.otpLog.deleteMany({ where: { order: { storeId: store.id } } });
    await db.codOrder.deleteMany({ where: { storeId: store.id } });
    await db.shippingRule.deleteMany({ where: { storeId: store.id } });
    await db.codForm.deleteMany({ where: { storeId: store.id } });
    await db.store.delete({ where: { id: store.id } });

    console.log(`[GDPR] Shop redact complete for ${shop}`);
  }

  // Remove Shopify sessions
  await db.session.deleteMany({ where: { shop } });

  return new Response("Shop data redacted", { status: 200 });
}
