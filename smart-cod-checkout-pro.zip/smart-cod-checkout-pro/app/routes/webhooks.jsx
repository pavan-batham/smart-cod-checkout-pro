import { authenticate } from "../shopify.server";
import { prisma } from "../db.server";

export async function action({ request }) {
  const { topic, shop, session, payload } = await authenticate.webhook(request);

  console.log(`Webhook received: ${topic} for ${shop}`);

  switch (topic) {
    case "APP_UNINSTALLED":
      await prisma.store.update({
        where: { shop },
        data: { isActive: false },
      });
      break;

    case "ORDERS_CREATE":
      // Shopify order created (not from our app) - log it
      console.log("Shopify order created:", payload?.id);
      break;

    case "ORDERS_UPDATED":
      // Update our order status when Shopify order changes
      if (payload?.id) {
        const shopifyOrderId = `gid://shopify/Order/${payload.id}`;
        const codOrder = await prisma.codOrder.findFirst({
          where: { shop, shopifyOrderId },
        });
        if (codOrder) {
          let newStatus = codOrder.status;
          if (payload.financial_status === "paid") newStatus = "confirmed";
          if (payload.fulfillment_status === "fulfilled") newStatus = "delivered";
          if (payload.cancelled_at) newStatus = "cancelled";

          await prisma.codOrder.update({
            where: { id: codOrder.id },
            data: { status: newStatus },
          });
        }
      }
      break;

    case "APP_SUBSCRIPTIONS_UPDATE":
      // Billing status changed
      if (payload?.app_subscription) {
        const sub = payload.app_subscription;
        const newPlan = sub.status === "ACTIVE"
          ? (sub.name?.toLowerCase().includes("pro") ? "pro" : "basic")
          : "free";

        await prisma.store.update({
          where: { shop },
          data: {
            plan: newPlan,
            billingId: String(sub.id),
            planExpiresAt: sub.current_period_end ? new Date(sub.current_period_end) : null,
          },
        });
      }
      break;

    default:
      console.log(`Unhandled webhook topic: ${topic}`);
  }

  return new Response(null, { status: 200 });
}
