import { json } from "@remix-run/node";
import { prisma } from "../db.server";
import { unauthenticated } from "../shopify.server";
import { detectFakeOrder } from "../utils/fakeOrderDetection.server";
import { sendOtp } from "../utils/otp.server";
import { sendNotifications } from "../utils/notifications.server";
import { syncToGoogleSheets } from "../utils/sheets.server";
import { createShopifyOrder } from "../utils/shopifyOrder.server";

export async function loader({ request }) {
  // CORS preflight
  return new Response(null, {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}

export async function action({ request }) {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };

  if (request.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await request.json();
    const {
      shop,
      formId,
      name,
      phone,
      email,
      address,
      city,
      state,
      pincode,
      notes,
      productId,
      productTitle,
      variantId,
      variantTitle,
      quantity = 1,
      productPrice,
      discountCode,
      utmSource,
      utmMedium,
      utmCampaign,
    } = body;

    if (!shop || !name || !phone || !address || !city || !state || !pincode || !productId) {
      return json(
        { success: false, error: "Missing required fields" },
        { status: 400, headers: corsHeaders }
      );
    }

    // Get store settings
    const store = await prisma.store.findUnique({ where: { shop } });
    if (!store || !store.isActive) {
      return json(
        { success: false, error: "Store not found or inactive" },
        { status: 404, headers: corsHeaders }
      );
    }

    // Get form config
    const form = formId
      ? await prisma.codForm.findUnique({ where: { id: formId } })
      : await prisma.codForm.findFirst({ where: { shop, isDefault: true, isActive: true } });

    // Calculate shipping
    const shippingRule = await prisma.shippingRule.findFirst({
      where: { shop, isActive: true },
      orderBy: { isDefault: "desc" },
    });

    let shippingCharge = 0;
    if (shippingRule) {
      if (shippingRule.type === "flat") {
        shippingCharge = shippingRule.charge;
      } else if (shippingRule.type === "free_above") {
        const subtotal = productPrice * quantity;
        shippingCharge = subtotal >= (shippingRule.freeAbove || 0) ? 0 : shippingRule.charge;
      } else if (shippingRule.type === "state_based" && shippingRule.states?.includes(state)) {
        shippingCharge = shippingRule.charge;
      }
    }

    // Discount calculation
    let discountAmount = 0;
    if (form?.discountEnabled && discountCode && form.discountCode === discountCode) {
      if (form.discountType === "percentage") {
        discountAmount = (productPrice * quantity * form.discountValue) / 100;
      } else {
        discountAmount = form.discountValue || 0;
      }
    }

    const totalAmount = Math.max(0, productPrice * quantity + shippingCharge - discountAmount);

    // Fake order detection
    const ipAddress = request.headers.get("x-forwarded-for") || request.headers.get("cf-connecting-ip") || "";
    const userAgent = request.headers.get("user-agent") || "";
    const fakeCheck = await detectFakeOrder({ phone, email, store, ipAddress });

    // Create order in DB
    const order = await prisma.codOrder.create({
      data: {
        shop,
        formId: form?.id,
        name,
        phone,
        email,
        address,
        city,
        state,
        pincode,
        notes,
        productId: String(productId),
        productTitle,
        variantId: variantId ? String(variantId) : null,
        variantTitle,
        quantity: parseInt(quantity),
        productPrice: parseFloat(productPrice),
        shippingCharge,
        discountAmount,
        discountCode,
        totalAmount,
        isFake: fakeCheck.isFake,
        fakeReason: fakeCheck.reason,
        status: fakeCheck.isFake ? "fake" : "pending",
        ipAddress,
        userAgent,
        utmSource,
        utmMedium,
        utmCampaign,
      },
    });

    // OTP flow
    if (store.otpEnabled && !fakeCheck.isFake) {
      const otpResult = await sendOtp({ shop, phone, store });
      await prisma.codOrder.update({
        where: { id: order.id },
        data: {
          otpCode: otpResult.code,
          otpExpiresAt: new Date(Date.now() + 10 * 60 * 1000), // 10 min
        },
      });

      return json(
        {
          success: true,
          requireOtp: true,
          orderId: order.id,
          message: "OTP sent to your phone number",
        },
        { headers: corsHeaders }
      );
    }

    // Auto-create Shopify order if not fake
    if (!fakeCheck.isFake) {
      try {
        const shopifyOrder = await createShopifyOrder({ shop, order });
        if (shopifyOrder) {
          await prisma.codOrder.update({
            where: { id: order.id },
            data: {
              shopifyOrderId: shopifyOrder.id,
              shopifyOrderNumber: shopifyOrder.name,
              status: "confirmed",
            },
          });
        }
      } catch (err) {
        console.error("Shopify order creation failed:", err);
      }
    }

    // Send notifications (async, don't await)
    sendNotifications({ order, store }).catch(console.error);

    // Google Sheets sync (async)
    if (store.googleSheetsId && store.googleSheetsCredentials) {
      syncToGoogleSheets({ order, store }).catch(console.error);
    }

    // Log analytics event
    await prisma.analyticsEvent.create({
      data: {
        shop,
        formId: form?.id,
        event: "order_created",
        productId: String(productId),
        metadata: { totalAmount, quantity },
      },
    });

    return json(
      {
        success: true,
        requireOtp: false,
        orderId: order.id,
        message: form?.successMessage || "Order placed successfully! We'll contact you shortly.",
        redirect: form?.thankYouRedirect || null,
        isFake: fakeCheck.isFake,
      },
      { headers: corsHeaders }
    );
  } catch (err) {
    console.error("COD order error:", err);
    return json(
      { success: false, error: "Something went wrong. Please try again." },
      { status: 500, headers: corsHeaders }
    );
  }
}
