import { json, redirect } from "@remix-run/node";
import { useLoaderData, useSubmit, Form, useNavigation } from "@remix-run/react";
import {
  Page, Layout, Card, TextField, Select, Checkbox, ColorPicker, Button,
  BlockStack, InlineStack, Text, Badge, Tabs, FormLayout, RangeSlider,
  Banner, Divider, Box, Tag, InlineGrid,
} from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import { prisma } from "../db.server";
import { useState, useCallback } from "react";
import { nanoid } from "nanoid";

const DEFAULT_FIELDS = [
  { id: "name", label: "Full Name", type: "text", required: true, enabled: true, placeholder: "Enter your full name" },
  { id: "phone", label: "Phone Number", type: "phone", required: true, enabled: true, placeholder: "+91 XXXXX XXXXX" },
  { id: "email", label: "Email (optional)", type: "email", required: false, enabled: true, placeholder: "email@example.com" },
  { id: "address", label: "Full Address", type: "textarea", required: true, enabled: true, placeholder: "House No, Street, Area" },
  { id: "city", label: "City", type: "text", required: true, enabled: true, placeholder: "City" },
  { id: "state", label: "State", type: "select_state", required: true, enabled: true },
  { id: "pincode", label: "PIN Code", type: "text", required: true, enabled: true, placeholder: "6-digit PIN code" },
  { id: "notes", label: "Order Notes", type: "textarea", required: false, enabled: false, placeholder: "Any special instructions?" },
];

const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
  "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka",
  "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram",
  "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
  "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
  "Andaman and Nicobar Islands", "Chandigarh", "Delhi", "Jammu and Kashmir",
  "Ladakh", "Lakshadweep", "Puducherry",
];

export async function loader({ request, params }) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;

  if (params.id === "new") {
    return json({ form: null, shop });
  }

  const form = await prisma.codForm.findUnique({
    where: { id: params.id, shop },
  });

  if (!form) throw new Response("Form not found", { status: 404 });

  return json({ form, shop });
}

export async function action({ request, params }) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const body = await request.json();

  const data = {
    shop,
    name: body.name,
    slug: body.slug || `form-${nanoid(8)}`,
    layout: body.layout,
    template: body.template,
    triggerType: body.triggerType,
    btnText: body.btnText,
    btnBgColor: body.btnBgColor,
    btnTextColor: body.btnTextColor,
    btnBorderRadius: parseInt(body.btnBorderRadius),
    btnFontSize: parseInt(body.btnFontSize),
    btnFullWidth: body.btnFullWidth,
    showCartIcon: body.showCartIcon,
    formTitle: body.formTitle,
    formBgColor: body.formBgColor,
    formTextColor: body.formTextColor,
    accentColor: body.accentColor,
    fontFamily: body.fontFamily,
    customCss: body.customCss,
    logoUrl: body.logoUrl,
    brandName: body.brandName,
    fields: body.fields,
    discountEnabled: body.discountEnabled,
    discountCode: body.discountCode,
    discountType: body.discountType,
    discountValue: parseFloat(body.discountValue) || 0,
    showQuantity: body.showQuantity,
    minQuantity: parseInt(body.minQuantity) || 1,
    maxQuantity: parseInt(body.maxQuantity) || 10,
    trustBadges: body.trustBadges,
    urgencyText: body.urgencyText,
    successMessage: body.successMessage,
    thankYouRedirect: body.thankYouRedirect,
    allProducts: body.allProducts,
    productIds: body.productIds || [],
    isActive: body.isActive !== false,
  };

  let savedForm;
  if (params.id === "new") {
    savedForm = await prisma.codForm.create({ data });
  } else {
    savedForm = await prisma.codForm.update({
      where: { id: params.id, shop },
      data,
    });
  }

  return json({ success: true, form: savedForm });
}

export default function FormBuilder() {
  const { form: initialForm, shop } = useLoaderData();
  const submit = useSubmit();
  const navigation = useNavigation();
  const isSaving = navigation.state === "submitting";

  const [selectedTab, setSelectedTab] = useState(0);
  const [formState, setFormState] = useState({
    name: initialForm?.name || "My COD Form",
    slug: initialForm?.slug || `form-${Date.now()}`,
    layout: initialForm?.layout || "popup",
    template: initialForm?.template || "modern",
    triggerType: initialForm?.triggerType || "button",
    btnText: initialForm?.btnText || "Order Now – Cash on Delivery",
    btnBgColor: initialForm?.btnBgColor || "#FF6B00",
    btnTextColor: initialForm?.btnTextColor || "#FFFFFF",
    btnBorderRadius: initialForm?.btnBorderRadius || 8,
    btnFontSize: initialForm?.btnFontSize || 16,
    btnFullWidth: initialForm?.btnFullWidth !== false,
    showCartIcon: initialForm?.showCartIcon !== false,
    formTitle: initialForm?.formTitle || "Complete Your Order",
    formBgColor: initialForm?.formBgColor || "#FFFFFF",
    formTextColor: initialForm?.formTextColor || "#111111",
    accentColor: initialForm?.accentColor || "#FF6B00",
    fontFamily: initialForm?.fontFamily || "inherit",
    customCss: initialForm?.customCss || "",
    logoUrl: initialForm?.logoUrl || "",
    brandName: initialForm?.brandName || "",
    fields: initialForm?.fields || DEFAULT_FIELDS,
    discountEnabled: initialForm?.discountEnabled || false,
    discountCode: initialForm?.discountCode || "",
    discountType: initialForm?.discountType || "percentage",
    discountValue: initialForm?.discountValue || 10,
    showQuantity: initialForm?.showQuantity !== false,
    minQuantity: initialForm?.minQuantity || 1,
    maxQuantity: initialForm?.maxQuantity || 10,
    trustBadges: initialForm?.trustBadges !== false,
    urgencyText: initialForm?.urgencyText || "🔥 Limited Stock! Order now before it's too late",
    successMessage: initialForm?.successMessage || "Order placed successfully! We'll contact you shortly.",
    thankYouRedirect: initialForm?.thankYouRedirect || "",
    allProducts: initialForm?.allProducts !== false,
    productIds: initialForm?.productIds || [],
    isActive: initialForm?.isActive !== false,
  });

  const update = (key, value) => setFormState((s) => ({ ...s, [key]: value }));

  const handleSave = () => {
    submit(formState, {
      method: "post",
      encType: "application/json",
    });
  };

  const toggleField = (fieldId) => {
    update(
      "fields",
      formState.fields.map((f) =>
        f.id === fieldId ? { ...f, enabled: !f.enabled } : f
      )
    );
  };

  const toggleFieldRequired = (fieldId) => {
    update(
      "fields",
      formState.fields.map((f) =>
        f.id === fieldId ? { ...f, required: !f.required } : f
      )
    );
  };

  const tabs = [
    { id: "general", content: "General" },
    { id: "button", content: "Button Style" },
    { id: "form-design", content: "Form Design" },
    { id: "fields", content: "Form Fields" },
    { id: "discount", content: "Discount & Offers" },
    { id: "notifications", content: "Notifications" },
    { id: "targeting", content: "Targeting" },
  ];

  // Live preview button style
  const previewBtnStyle = {
    backgroundColor: formState.btnBgColor,
    color: formState.btnTextColor,
    borderRadius: `${formState.btnBorderRadius}px`,
    fontSize: `${formState.btnFontSize}px`,
    padding: "12px 24px",
    border: "none",
    cursor: "pointer",
    width: formState.btnFullWidth ? "100%" : "auto",
    fontWeight: "600",
    letterSpacing: "0.3px",
  };

  return (
    <Page
      title={initialForm ? `Edit: ${formState.name}` : "Create COD Form"}
      backAction={{ url: "/app/forms" }}
      primaryAction={{
        content: isSaving ? "Saving..." : "Save Form",
        onAction: handleSave,
        loading: isSaving,
      }}
      secondaryActions={[
        {
          content: formState.isActive ? "Deactivate" : "Activate",
          onAction: () => update("isActive", !formState.isActive),
        },
      ]}
    >
      <Layout>
        <Layout.Section>
          <Card>
            <Tabs tabs={tabs} selected={selectedTab} onSelect={setSelectedTab}>
              <Box padding="400">
                {/* ── General Tab ── */}
                {selectedTab === 0 && (
                  <FormLayout>
                    <TextField
                      label="Form Name"
                      value={formState.name}
                      onChange={(v) => update("name", v)}
                      autoComplete="off"
                    />
                    <Select
                      label="Layout Type"
                      options={[
                        { label: "Popup Modal", value: "popup" },
                        { label: "Embedded (Inline)", value: "embedded" },
                        { label: "Slide-in Drawer", value: "slide" },
                      ]}
                      value={formState.layout}
                      onChange={(v) => update("layout", v)}
                    />
                    <Select
                      label="Template Style"
                      options={[
                        { label: "Modern", value: "modern" },
                        { label: "Minimal", value: "minimal" },
                        { label: "Bold / High Contrast", value: "bold" },
                        { label: "Soft / Rounded", value: "soft" },
                      ]}
                      value={formState.template}
                      onChange={(v) => update("template", v)}
                    />
                    <Select
                      label="Trigger Type"
                      options={[
                        { label: "Button Click", value: "button" },
                        { label: "Auto (on page load)", value: "auto" },
                        { label: "Exit Intent", value: "exit_intent" },
                      ]}
                      value={formState.triggerType}
                      onChange={(v) => update("triggerType", v)}
                    />
                    <TextField
                      label="Form Title"
                      value={formState.formTitle}
                      onChange={(v) => update("formTitle", v)}
                    />
                    <TextField
                      label="Brand Name"
                      value={formState.brandName}
                      onChange={(v) => update("brandName", v)}
                    />
                    <TextField
                      label="Logo URL"
                      value={formState.logoUrl}
                      onChange={(v) => update("logoUrl", v)}
                    />
                    <TextField
                      label="Success Message"
                      value={formState.successMessage}
                      onChange={(v) => update("successMessage", v)}
                      multiline={2}
                    />
                    <TextField
                      label="Thank You Redirect URL (optional)"
                      value={formState.thankYouRedirect}
                      onChange={(v) => update("thankYouRedirect", v)}
                      placeholder="https://your-store.com/thank-you"
                    />
                    <TextField
                      label="Urgency Text"
                      value={formState.urgencyText}
                      onChange={(v) => update("urgencyText", v)}
                      placeholder="🔥 Limited Stock! Order now before it's too late"
                    />
                    <Checkbox
                      label="Show Trust Badges (Secure, COD, Free Returns)"
                      checked={formState.trustBadges}
                      onChange={(v) => update("trustBadges", v)}
                    />
                  </FormLayout>
                )}

                {/* ── Button Style Tab ── */}
                {selectedTab === 1 && (
                  <BlockStack gap="400">
                    <Text variant="headingMd">Button Preview</Text>
                    <Box
                      padding="400"
                      background="bg-surface-secondary"
                      borderRadius="200"
                    >
                      <button style={previewBtnStyle}>
                        {formState.showCartIcon && "🛒 "}
                        {formState.btnText}
                      </button>
                    </Box>
                    <Divider />
                    <FormLayout>
                      <TextField
                        label="Button Text"
                        value={formState.btnText}
                        onChange={(v) => update("btnText", v)}
                      />
                      <InlineGrid columns={2} gap="400">
                        <TextField
                          label="Background Color"
                          value={formState.btnBgColor}
                          onChange={(v) => update("btnBgColor", v)}
                          prefix={
                            <div
                              style={{
                                width: 20,
                                height: 20,
                                borderRadius: 4,
                                backgroundColor: formState.btnBgColor,
                                border: "1px solid #ccc",
                              }}
                            />
                          }
                        />
                        <TextField
                          label="Text Color"
                          value={formState.btnTextColor}
                          onChange={(v) => update("btnTextColor", v)}
                          prefix={
                            <div
                              style={{
                                width: 20,
                                height: 20,
                                borderRadius: 4,
                                backgroundColor: formState.btnTextColor,
                                border: "1px solid #ccc",
                              }}
                            />
                          }
                        />
                      </InlineGrid>
                      <RangeSlider
                        label={`Border Radius: ${formState.btnBorderRadius}px`}
                        value={formState.btnBorderRadius}
                        min={0}
                        max={50}
                        onChange={(v) => update("btnBorderRadius", v)}
                        output
                      />
                      <RangeSlider
                        label={`Font Size: ${formState.btnFontSize}px`}
                        value={formState.btnFontSize}
                        min={12}
                        max={24}
                        onChange={(v) => update("btnFontSize", v)}
                        output
                      />
                      <Checkbox
                        label="Full Width Button"
                        checked={formState.btnFullWidth}
                        onChange={(v) => update("btnFullWidth", v)}
                      />
                      <Checkbox
                        label="Show Cart Icon"
                        checked={formState.showCartIcon}
                        onChange={(v) => update("showCartIcon", v)}
                      />
                    </FormLayout>
                  </BlockStack>
                )}

                {/* ── Form Design Tab ── */}
                {selectedTab === 2 && (
                  <FormLayout>
                    <InlineGrid columns={2} gap="400">
                      <TextField
                        label="Form Background Color"
                        value={formState.formBgColor}
                        onChange={(v) => update("formBgColor", v)}
                      />
                      <TextField
                        label="Text Color"
                        value={formState.formTextColor}
                        onChange={(v) => update("formTextColor", v)}
                      />
                    </InlineGrid>
                    <TextField
                      label="Accent / Button Color"
                      value={formState.accentColor}
                      onChange={(v) => update("accentColor", v)}
                    />
                    <Select
                      label="Font Family"
                      options={[
                        { label: "Inherit from Theme", value: "inherit" },
                        { label: "Inter", value: "Inter, sans-serif" },
                        { label: "Poppins", value: "Poppins, sans-serif" },
                        { label: "Roboto", value: "Roboto, sans-serif" },
                        { label: "Nunito", value: "Nunito, sans-serif" },
                      ]}
                      value={formState.fontFamily}
                      onChange={(v) => update("fontFamily", v)}
                    />
                    <TextField
                      label="Custom CSS"
                      value={formState.customCss}
                      onChange={(v) => update("customCss", v)}
                      multiline={6}
                      placeholder=".scod-form { /* custom styles */ }"
                    />
                  </FormLayout>
                )}

                {/* ── Fields Tab ── */}
                {selectedTab === 3 && (
                  <BlockStack gap="300">
                    <Text tone="subdued">
                      Toggle fields on/off and set required status. Drag to reorder (coming soon).
                    </Text>
                    {formState.fields.map((field) => (
                      <Card key={field.id}>
                        <InlineStack align="space-between">
                          <BlockStack gap="100">
                            <InlineStack gap="200">
                              <Text fontWeight="bold">{field.label}</Text>
                              <Badge>{field.type}</Badge>
                              {field.required && (
                                <Badge tone="critical">Required</Badge>
                              )}
                            </InlineStack>
                          </BlockStack>
                          <InlineStack gap="300">
                            <Checkbox
                              label="Required"
                              checked={field.required}
                              onChange={() => toggleFieldRequired(field.id)}
                            />
                            <Checkbox
                              label="Enabled"
                              checked={field.enabled}
                              onChange={() => toggleField(field.id)}
                            />
                          </InlineStack>
                        </InlineStack>
                      </Card>
                    ))}
                    <Button
                      onClick={() => {
                        const newField = {
                          id: `custom_${nanoid(6)}`,
                          label: "Custom Field",
                          type: "text",
                          required: false,
                          enabled: true,
                          placeholder: "",
                        };
                        update("fields", [...formState.fields, newField]);
                      }}
                    >
                      + Add Custom Field
                    </Button>
                    <Checkbox
                      label="Show Quantity Selector"
                      checked={formState.showQuantity}
                      onChange={(v) => update("showQuantity", v)}
                    />
                    {formState.showQuantity && (
                      <InlineGrid columns={2} gap="400">
                        <TextField
                          label="Min Quantity"
                          type="number"
                          value={String(formState.minQuantity)}
                          onChange={(v) => update("minQuantity", parseInt(v))}
                        />
                        <TextField
                          label="Max Quantity"
                          type="number"
                          value={String(formState.maxQuantity)}
                          onChange={(v) => update("maxQuantity", parseInt(v))}
                        />
                      </InlineGrid>
                    )}
                  </BlockStack>
                )}

                {/* ── Discount Tab ── */}
                {selectedTab === 4 && (
                  <FormLayout>
                    <Checkbox
                      label="Enable Discount / Coupon Code"
                      checked={formState.discountEnabled}
                      onChange={(v) => update("discountEnabled", v)}
                    />
                    {formState.discountEnabled && (
                      <>
                        <TextField
                          label="Discount Code"
                          value={formState.discountCode}
                          onChange={(v) => update("discountCode", v)}
                          placeholder="SAVE10"
                        />
                        <Select
                          label="Discount Type"
                          options={[
                            { label: "Percentage (%)", value: "percentage" },
                            { label: "Fixed Amount (₹)", value: "fixed" },
                          ]}
                          value={formState.discountType}
                          onChange={(v) => update("discountType", v)}
                        />
                        <TextField
                          label="Discount Value"
                          type="number"
                          value={String(formState.discountValue)}
                          onChange={(v) => update("discountValue", v)}
                          suffix={formState.discountType === "percentage" ? "%" : "₹"}
                        />
                      </>
                    )}
                  </FormLayout>
                )}

                {/* ── Targeting Tab ── */}
                {selectedTab === 6 && (
                  <FormLayout>
                    <Checkbox
                      label="Show on All Products"
                      checked={formState.allProducts}
                      onChange={(v) => update("allProducts", v)}
                    />
                    {!formState.allProducts && (
                      <TextField
                        label="Product IDs (comma separated)"
                        value={formState.productIds.join(", ")}
                        onChange={(v) =>
                          update(
                            "productIds",
                            v.split(",").map((s) => s.trim()).filter(Boolean)
                          )
                        }
                        placeholder="gid://shopify/Product/123, gid://shopify/Product/456"
                        multiline={2}
                      />
                    )}
                  </FormLayout>
                )}
              </Box>
            </Tabs>
          </Card>
        </Layout.Section>

        <Layout.Section variant="oneThird">
          <BlockStack gap="400">
            <Card>
              <BlockStack gap="300">
                <Text variant="headingMd">Form Status</Text>
                <Divider />
                <InlineStack align="space-between">
                  <Text>Status</Text>
                  <Badge tone={formState.isActive ? "success" : "critical"}>
                    {formState.isActive ? "Active" : "Inactive"}
                  </Badge>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text>Layout</Text>
                  <Badge>{formState.layout}</Badge>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text>Template</Text>
                  <Badge>{formState.template}</Badge>
                </InlineStack>
              </BlockStack>
            </Card>

            <Card>
              <BlockStack gap="300">
                <Text variant="headingMd">Live Preview</Text>
                <Divider />
                <Box
                  padding="300"
                  background="bg-surface-secondary"
                  borderRadius="200"
                >
                  <BlockStack gap="200">
                    <div
                      style={{
                        backgroundColor: formState.formBgColor,
                        borderRadius: 12,
                        padding: 16,
                        boxShadow: "0 4px 24px rgba(0,0,0,0.1)",
                        fontFamily: formState.fontFamily,
                        color: formState.formTextColor,
                      }}
                    >
                      {formState.logoUrl && (
                        <img
                          src={formState.logoUrl}
                          alt="logo"
                          style={{ height: 32, marginBottom: 8 }}
                        />
                      )}
                      <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 12 }}>
                        {formState.formTitle}
                      </div>
                      {formState.urgencyText && (
                        <div
                          style={{
                            backgroundColor: "#FFF3CD",
                            padding: "6px 10px",
                            borderRadius: 6,
                            fontSize: 12,
                            marginBottom: 10,
                            color: "#856404",
                          }}
                        >
                          {formState.urgencyText}
                        </div>
                      )}
                      <div
                        style={{
                          height: 32,
                          backgroundColor: "#f5f5f5",
                          borderRadius: 6,
                          marginBottom: 8,
                        }}
                      />
                      <div
                        style={{
                          height: 32,
                          backgroundColor: "#f5f5f5",
                          borderRadius: 6,
                          marginBottom: 12,
                        }}
                      />
                      <button
                        style={{
                          ...previewBtnStyle,
                          fontSize: "13px",
                          padding: "10px 16px",
                        }}
                      >
                        {formState.showCartIcon && "🛒 "}{formState.btnText}
                      </button>
                      {formState.trustBadges && (
                        <div
                          style={{
                            marginTop: 10,
                            fontSize: 11,
                            color: "#666",
                            textAlign: "center",
                          }}
                        >
                          🔒 Secure &nbsp;|&nbsp; 💵 Cash on Delivery &nbsp;|&nbsp; ↩ Easy Returns
                        </div>
                      )}
                    </div>
                  </BlockStack>
                </Box>
              </BlockStack>
            </Card>
          </BlockStack>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
