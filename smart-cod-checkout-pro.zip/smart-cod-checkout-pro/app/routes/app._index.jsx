import { json } from "@remix-run/node";
import { useLoaderData, Link } from "@remix-run/react";
import {
  Page,
  Layout,
  Card,
  Text,
  BlockStack,
  InlineGrid,
  Badge,
  DataTable,
  Button,
  Banner,
  Box,
  InlineStack,
  Icon,
  Divider,
} from "@shopify/polaris";
import {
  OrdersFilledIcon,
  ChartVerticalFilledIcon,
  PersonFilledIcon,
  CashDollarIcon,
} from "@shopify/polaris-icons";
import { authenticate } from "../shopify.server";
import { prisma } from "../db.server";

export async function loader({ request }) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;

  const [store, totalOrders, todayOrders, recentOrders] = await Promise.all([
    prisma.store.findUnique({ where: { shop } }),
    prisma.codOrder.count({ where: { shop } }),
    prisma.codOrder.count({
      where: {
        shop,
        createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) },
      },
    }),
    prisma.codOrder.findMany({
      where: { shop },
      orderBy: { createdAt: "desc" },
      take: 10,
    }),
  ]);

  const revenue = await prisma.codOrder.aggregate({
    where: { shop, status: { not: "cancelled" } },
    _sum: { totalAmount: true },
  });

  const confirmedOrders = await prisma.codOrder.count({
    where: { shop, status: "confirmed" },
  });

  return json({
    shop,
    store,
    stats: {
      totalOrders,
      todayOrders,
      revenue: revenue._sum.totalAmount || 0,
      confirmedOrders,
    },
    recentOrders,
  });
}

export default function Dashboard() {
  const { stats, recentOrders, store, shop } = useLoaderData();

  const statCards = [
    {
      title: "Total Orders",
      value: stats.totalOrders,
      icon: OrdersFilledIcon,
      color: "#FF6B00",
    },
    {
      title: "Today's Orders",
      value: stats.todayOrders,
      icon: ChartVerticalFilledIcon,
      color: "#00A36C",
    },
    {
      title: "Total Revenue",
      value: `₹${stats.revenue.toLocaleString("en-IN")}`,
      icon: CashDollarIcon,
      color: "#8B5CF6",
    },
    {
      title: "Confirmed",
      value: stats.confirmedOrders,
      icon: PersonFilledIcon,
      color: "#0EA5E9",
    },
  ];

  const rows = recentOrders.map((order) => [
    order.shopifyOrderNumber || order.id.slice(-6).toUpperCase(),
    order.name,
    order.phone,
    order.productTitle,
    `₹${order.totalAmount}`,
    <Badge
      tone={
        order.status === "confirmed"
          ? "success"
          : order.status === "cancelled"
          ? "critical"
          : order.status === "fake"
          ? "warning"
          : "info"
      }
    >
      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
    </Badge>,
    new Date(order.createdAt).toLocaleDateString("en-IN"),
  ]);

  return (
    <Page
      title="Smart COD Checkout Pro"
      subtitle={`Managing ${shop}`}
      primaryAction={
        <Button variant="primary" url="/app/forms/new">
          Create New Form
        </Button>
      }
    >
      <BlockStack gap="500">
        {!store?.plan || store.plan === "free" ? (
          <Banner
            title="Upgrade to Pro for unlimited orders & advanced features"
            tone="info"
            action={{ content: "View Plans", url: "/app/billing" }}
          />
        ) : null}

        <InlineGrid columns={4} gap="400">
          {statCards.map((card) => (
            <Card key={card.title}>
              <BlockStack gap="200">
                <InlineStack align="space-between">
                  <Text variant="headingSm" as="h3" tone="subdued">
                    {card.title}
                  </Text>
                  <Icon source={card.icon} />
                </InlineStack>
                <Text variant="heading2xl" as="p">
                  {card.value}
                </Text>
              </BlockStack>
            </Card>
          ))}
        </InlineGrid>

        <Layout>
          <Layout.Section>
            <Card>
              <BlockStack gap="400">
                <InlineStack align="space-between">
                  <Text variant="headingMd" as="h2">
                    Recent Orders
                  </Text>
                  <Button url="/app/orders" variant="plain">
                    View all
                  </Button>
                </InlineStack>
                <DataTable
                  columnContentTypes={[
                    "text", "text", "text", "text", "numeric", "text", "text",
                  ]}
                  headings={[
                    "Order #", "Customer", "Phone", "Product",
                    "Amount", "Status", "Date",
                  ]}
                  rows={rows}
                  emptyState={
                    <Box padding="800" textAlign="center">
                      <BlockStack gap="300" align="center" inlineAlign="center">
                        <Text tone="subdued">No orders yet.</Text>
                        <Button url="/app/forms">Set up your first form</Button>
                      </BlockStack>
                    </Box>
                  }
                />
              </BlockStack>
            </Card>
          </Layout.Section>

          <Layout.Section variant="oneThird">
            <BlockStack gap="400">
              <Card>
                <BlockStack gap="300">
                  <Text variant="headingMd" as="h2">Quick Actions</Text>
                  <Divider />
                  <Button url="/app/forms/new" fullWidth>Create COD Form</Button>
                  <Button url="/app/orders/export" fullWidth variant="secondary">
                    Export Orders (CSV)
                  </Button>
                  <Button url="/app/settings" fullWidth variant="secondary">
                    Configure Notifications
                  </Button>
                  <Button url="/app/shipping" fullWidth variant="secondary">
                    Shipping Rules
                  </Button>
                </BlockStack>
              </Card>

              <Card>
                <BlockStack gap="300">
                  <Text variant="headingMd" as="h2">Current Plan</Text>
                  <Divider />
                  <InlineStack align="space-between">
                    <Text>Plan</Text>
                    <Badge tone={store?.plan === "pro" ? "success" : "info"}>
                      {(store?.plan || "free").toUpperCase()}
                    </Badge>
                  </InlineStack>
                  {store?.plan !== "pro" && (
                    <Button url="/app/billing" variant="primary" fullWidth>
                      Upgrade Now
                    </Button>
                  )}
                </BlockStack>
              </Card>
            </BlockStack>
          </Layout.Section>
        </Layout>
      </BlockStack>
    </Page>
  );
}
