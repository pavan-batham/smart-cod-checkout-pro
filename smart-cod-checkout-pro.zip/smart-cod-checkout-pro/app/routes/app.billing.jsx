import { json, redirect } from "@remix-run/node";
import { useLoaderData, useSubmit } from "@remix-run/react";
import {
  Page, Layout, Card, Text, BlockStack, Button, Badge,
  List, InlineStack, Divider, Box, Banner,
} from "@shopify/polaris";
import { authenticate, MONTHLY_PLAN, ANNUAL_PLAN } from "../shopify.server";
import { prisma } from "../db.server";

const PLANS = [
  {
    id: "free",
    name: "Free",
    price: 0,
    currency: "USD",
    interval: "month",
    features: [
      "1 COD form",
      "Up to 50 orders/month",
      "Basic form templates",
      "Email notifications",
      "Shopify order sync",
    ],
    limitations: [
      "No OTP verification",
      "No analytics",
      "No pixel integration",
      "No Google Sheets sync",
    ],
    cta: "Current Plan",
    shopifyPlanName: null,
  },
  {
    id: "basic",
    name: "Basic",
    price: 9.99,
    currency: "USD",
    interval: "month",
    features: [
      "5 COD forms",
      "Up to 500 orders/month",
      "All templates",
      "SMS + WhatsApp notifications",
      "OTP verification",
      "Facebook & TikTok Pixel",
      "Google Analytics",
      "Analytics dashboard",
      "CSV/Excel export",
      "Abandoned order recovery",
    ],
    cta: "Upgrade to Basic",
    shopifyPlanName: "Basic Plan",
    trialDays: 7,
  },
  {
    id: "pro",
    name: "Pro",
    price: 24.99,
    currency: "USD",
    interval: "month",
    popular: true,
    features: [
      "Unlimited COD forms",
      "Unlimited orders",
      "All Basic features +",
      "Google Sheets integration",
      "Multi-language support",
      "Custom CSS",
      "Advanced fake order detection",
      "Priority support",
      "White-label branding",
      "Multi-store support",
      "API access",
    ],
    cta: "Upgrade to Pro",
    shopifyPlanName: "Pro Plan",
    trialDays: 14,
  },
];

export async function loader({ request }) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const store = await prisma.store.findUnique({ where: { shop } });
  return json({ store, currentPlan: store?.plan || "free" });
}

export async function action({ request }) {
  const { session, billing } = await authenticate.admin(request);
  const formData = await request.formData();
  const planId = formData.get("planId");

  const plan = PLANS.find((p) => p.id === planId);
  if (!plan || !plan.shopifyPlanName) {
    return json({ error: "Invalid plan" }, { status: 400 });
  }

  try {
    const billingCheck = await billing.require({
      plans: [
        {
          amount: plan.price,
          currencyCode: plan.currency,
          interval: "EVERY_30_DAYS",
          trialDays: plan.trialDays || 0,
        },
      ],
      onFailure: async () => {
        const confirmUrl = await billing.request({
          plan: {
            amount: plan.price,
            currencyCode: plan.currency,
            interval: "EVERY_30_DAYS",
            trialDays: plan.trialDays || 0,
          },
          isTest: process.env.NODE_ENV !== "production",
          returnUrl: `${process.env.SHOPIFY_APP_URL}/app/billing?success=1`,
        });
        return redirect(confirmUrl);
      },
    });
    return json({ success: true });
  } catch (err) {
    return json({ error: err.message }, { status: 500 });
  }
}

export default function BillingPage() {
  const { currentPlan } = useLoaderData();
  const submit = useSubmit();

  const handleUpgrade = (planId) => {
    submit({ planId }, { method: "post" });
  };

  return (
    <Page title="Subscription Plans">
      <BlockStack gap="500">
        <Banner tone="info">
          All plans include a free trial. You will only be charged through Shopify billing —
          no credit card required upfront.
        </Banner>

        <InlineStack gap="400" align="center" wrap={false}>
          {PLANS.map((plan) => (
            <Card key={plan.id}>
              <BlockStack gap="400">
                <Box>
                  <InlineStack align="space-between">
                    <Text variant="headingLg" fontWeight="bold">
                      {plan.name}
                    </Text>
                    {plan.popular && <Badge tone="success">Most Popular</Badge>}
                    {currentPlan === plan.id && <Badge tone="info">Current</Badge>}
                  </InlineStack>
                  <Text variant="heading2xl" as="p" fontWeight="bold">
                    {plan.price === 0 ? "Free" : `$${plan.price}`}
                    {plan.price > 0 && (
                      <Text variant="bodySm" tone="subdued"> /month</Text>
                    )}
                  </Text>
                  {plan.trialDays && (
                    <Text tone="success" variant="bodySm">
                      {plan.trialDays}-day free trial
                    </Text>
                  )}
                </Box>

                <Divider />

                <BlockStack gap="200">
                  <Text fontWeight="semibold">Included:</Text>
                  <List type="bullet">
                    {plan.features.map((f) => (
                      <List.Item key={f}>{f}</List.Item>
                    ))}
                  </List>
                  {plan.limitations && (
                    <>
                      <Text fontWeight="semibold" tone="critical">Not included:</Text>
                      <List type="bullet">
                        {plan.limitations.map((l) => (
                          <List.Item key={l}><Text tone="subdued">{l}</Text></List.Item>
                        ))}
                      </List>
                    </>
                  )}
                </BlockStack>

                <Button
                  variant={plan.popular ? "primary" : "secondary"}
                  fullWidth
                  disabled={currentPlan === plan.id}
                  onClick={() => plan.shopifyPlanName && handleUpgrade(plan.id)}
                >
                  {currentPlan === plan.id ? "Current Plan" : plan.cta}
                </Button>
              </BlockStack>
            </Card>
          ))}
        </InlineStack>

        <Card>
          <BlockStack gap="300">
            <Text variant="headingMd">Billing FAQ</Text>
            <Divider />
            <Text fontWeight="semibold">How does billing work?</Text>
            <Text tone="subdued">
              All charges are processed through Shopify's billing system. You'll see the
              charge on your Shopify invoice — no separate payment needed.
            </Text>
            <Text fontWeight="semibold">Can I cancel anytime?</Text>
            <Text tone="subdued">
              Yes. You can cancel anytime from your Shopify admin under Apps. You'll retain
              access until the end of your billing period.
            </Text>
            <Text fontWeight="semibold">Is there a free trial?</Text>
            <Text tone="subdued">
              Yes — Basic has a 7-day trial and Pro has a 14-day trial, no credit card required.
            </Text>
          </BlockStack>
        </Card>
      </BlockStack>
    </Page>
  );
}
