import { json } from "@remix-run/node";
import { useLoaderData, useSubmit, Form } from "@remix-run/react";
import {
  Page, Card, IndexTable, Badge, Button, Text, Filters, Select,
  useIndexResourceState, BlockStack, InlineStack, Modal, TextField,
  Toast, Frame,
} from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import { prisma } from "../db.server";
import { useState } from "react";
import { exportOrdersToCSV } from "../utils/export.server";

export async function loader({ request }) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const url = new URL(request.url);
  const status = url.searchParams.get("status") || "";
  const search = url.searchParams.get("search") || "";
  const page = parseInt(url.searchParams.get("page") || "1");
  const perPage = 25;

  const where = {
    shop,
    ...(status ? { status } : {}),
    ...(search
      ? {
          OR: [
            { name: { contains: search, mode: "insensitive" } },
            { phone: { contains: search } },
            { shopifyOrderNumber: { contains: search } },
          ],
        }
      : {}),
  };

  const [orders, total] = await Promise.all([
    prisma.codOrder.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * perPage,
      take: perPage,
    }),
    prisma.codOrder.count({ where }),
  ]);

  return json({ orders, total, page, perPage, status, search });
}

export async function action({ request }) {
  const { session, admin } = await authenticate.admin(request);
  const shop = session.shop;
  const formData = await request.formData();
  const intent = formData.get("intent");

  if (intent === "update_status") {
    const orderId = formData.get("orderId");
    const status = formData.get("status");
    await prisma.codOrder.update({
      where: { id: orderId, shop },
      data: { status },
    });
    return json({ success: true });
  }

  if (intent === "sync_shopify") {
    const orderId = formData.get("orderId");
    const order = await prisma.codOrder.findUnique({ where: { id: orderId } });

    try {
      const mutation = `#graphql
        mutation orderCreate($order: OrderCreateOrderInput!, $options: OrderCreateOptionsInput) {
          orderCreate(order: $order, options: $options) {
            userErrors { field message }
            order {
              id
              name
              displayFinancialStatus
            }
          }
        }
      `;

      const response = await admin.graphql(mutation, {
        variables: {
          order: {
            lineItems: [
              {
                variantId: order.variantId || `gid://shopify/ProductVariant/${order.productId}`,
                quantity: order.quantity,
              },
            ],
            shippingAddress: {
              firstName: order.name.split(" ")[0],
              lastName: order.name.split(" ").slice(1).join(" ") || "-",
              address1: order.address,
              city: order.city,
              province: order.state,
              zip: order.pincode,
              countryCode: "IN",
              phone: order.phone,
            },
            phone: order.phone,
            note: order.notes || "",
            tags: ["COD", "Smart-COD-Checkout-Pro"],
            paymentGateway: "Cash on Delivery",
          },
          options: { sendReceipt: false, sendFulfillmentReceipt: false },
        },
      });

      const data = await response.json();
      const shopifyOrder = data.data?.orderCreate?.order;

      if (shopifyOrder) {
        await prisma.codOrder.update({
          where: { id: orderId },
          data: {
            shopifyOrderId: shopifyOrder.id,
            shopifyOrderNumber: shopifyOrder.name,
            status: "confirmed",
          },
        });
        return json({ success: true, shopifyOrder });
      }

      return json({
        error: data.data?.orderCreate?.userErrors?.[0]?.message || "Sync failed",
      });
    } catch (err) {
      return json({ error: err.message }, { status: 500 });
    }
  }

  if (intent === "export_csv") {
    const orders = await prisma.codOrder.findMany({
      where: { shop },
      orderBy: { createdAt: "desc" },
    });
    const csv = exportOrdersToCSV(orders);
    return new Response(csv, {
      headers: {
        "Content-Type": "text/csv",
        "Content-Disposition": `attachment; filename="cod-orders-${Date.now()}.csv"`,
      },
    });
  }

  return json({ error: "Unknown intent" }, { status: 400 });
}

const STATUS_OPTIONS = [
  { label: "All", value: "" },
  { label: "Pending", value: "pending" },
  { label: "Confirmed", value: "confirmed" },
  { label: "Processing", value: "processing" },
  { label: "Shipped", value: "shipped" },
  { label: "Delivered", value: "delivered" },
  { label: "Cancelled", value: "cancelled" },
  { label: "Fake / Blocked", value: "fake" },
];

const STATUS_TONES = {
  pending: "info",
  confirmed: "success",
  processing: "attention",
  shipped: "attention",
  delivered: "success",
  cancelled: "critical",
  fake: "warning",
};

export default function OrdersPage() {
  const { orders, total, page, perPage, status, search } = useLoaderData();
  const submit = useSubmit();
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [toast, setToast] = useState(null);

  const { selectedResources, allResourcesSelected, handleSelectionChange } =
    useIndexResourceState(orders);

  const handleStatusChange = (orderId, newStatus) => {
    submit({ intent: "update_status", orderId, status: newStatus }, { method: "post" });
  };

  const handleSyncShopify = (orderId) => {
    submit({ intent: "sync_shopify", orderId }, { method: "post" });
    setToast("Syncing to Shopify...");
  };

  const rowMarkup = orders.map((order, index) => (
    <IndexTable.Row
      id={order.id}
      key={order.id}
      selected={selectedResources.includes(order.id)}
      position={index}
    >
      <IndexTable.Cell>
        <Text fontWeight="bold">
          {order.shopifyOrderNumber || `#COD-${order.id.slice(-6).toUpperCase()}`}
        </Text>
      </IndexTable.Cell>
      <IndexTable.Cell>{order.name}</IndexTable.Cell>
      <IndexTable.Cell>{order.phone}</IndexTable.Cell>
      <IndexTable.Cell>
        <Text truncate>{order.productTitle}</Text>
        {order.variantTitle && (
          <Text tone="subdued" variant="bodySm">
            {order.variantTitle}
          </Text>
        )}
      </IndexTable.Cell>
      <IndexTable.Cell>Qty: {order.quantity}</IndexTable.Cell>
      <IndexTable.Cell>
        <Text fontWeight="semibold">₹{order.totalAmount}</Text>
      </IndexTable.Cell>
      <IndexTable.Cell>
        <Badge tone={STATUS_TONES[order.status] || "info"}>
          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
        </Badge>
      </IndexTable.Cell>
      <IndexTable.Cell>
        {new Date(order.createdAt).toLocaleDateString("en-IN")}
      </IndexTable.Cell>
      <IndexTable.Cell>
        <InlineStack gap="200">
          <Button variant="plain" onClick={() => setSelectedOrder(order)}>
            View
          </Button>
          {!order.shopifyOrderId && (
            <Button
              variant="plain"
              tone="success"
              onClick={() => handleSyncShopify(order.id)}
            >
              Sync
            </Button>
          )}
        </InlineStack>
      </IndexTable.Cell>
    </IndexTable.Row>
  ));

  return (
    <Frame>
      <Page
        title="COD Orders"
        subtitle={`${total} total orders`}
        primaryAction={{
          content: "Export CSV",
          onAction: () =>
            submit({ intent: "export_csv" }, { method: "post" }),
        }}
      >
        <BlockStack gap="400">
          <Card>
            <BlockStack gap="400">
              <InlineStack gap="300">
                <div style={{ flex: 1 }}>
                  <Form method="get">
                    <InlineStack gap="300">
                      <TextField
                        name="search"
                        placeholder="Search by name, phone, order #"
                        defaultValue={search}
                        clearButton
                        onClearButtonClick={() =>
                          submit({ search: "" }, { method: "get" })
                        }
                      />
                      <Select
                        name="status"
                        label=""
                        options={STATUS_OPTIONS}
                        value={status}
                        onChange={(v) =>
                          submit({ status: v, search }, { method: "get" })
                        }
                      />
                      <Button submit>Filter</Button>
                    </InlineStack>
                  </Form>
                </div>
              </InlineStack>

              <IndexTable
                resourceName={{ singular: "order", plural: "orders" }}
                itemCount={orders.length}
                selectedItemsCount={
                  allResourcesSelected ? "All" : selectedResources.length
                }
                onSelectionChange={handleSelectionChange}
                headings={[
                  { title: "Order #" },
                  { title: "Customer" },
                  { title: "Phone" },
                  { title: "Product" },
                  { title: "Qty" },
                  { title: "Amount" },
                  { title: "Status" },
                  { title: "Date" },
                  { title: "Actions" },
                ]}
              >
                {rowMarkup}
              </IndexTable>
            </BlockStack>
          </Card>
        </BlockStack>

        {/* Order Detail Modal */}
        {selectedOrder && (
          <Modal
            open={!!selectedOrder}
            onClose={() => setSelectedOrder(null)}
            title={`Order Details – ${selectedOrder.name}`}
            primaryAction={{
              content: "Close",
              onAction: () => setSelectedOrder(null),
            }}
            secondaryActions={[
              {
                content: "Sync to Shopify",
                onAction: () => {
                  handleSyncShopify(selectedOrder.id);
                  setSelectedOrder(null);
                },
                disabled: !!selectedOrder.shopifyOrderId,
              },
            ]}
          >
            <Modal.Section>
              <BlockStack gap="300">
                <InlineStack align="space-between">
                  <Text fontWeight="bold">Customer</Text>
                  <Text>{selectedOrder.name}</Text>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text fontWeight="bold">Phone</Text>
                  <Text>{selectedOrder.phone}</Text>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text fontWeight="bold">Email</Text>
                  <Text>{selectedOrder.email || "—"}</Text>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text fontWeight="bold">Address</Text>
                  <Text>{selectedOrder.address}</Text>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text fontWeight="bold">City / State</Text>
                  <Text>{selectedOrder.city}, {selectedOrder.state} – {selectedOrder.pincode}</Text>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text fontWeight="bold">Product</Text>
                  <Text>{selectedOrder.productTitle}</Text>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text fontWeight="bold">Qty</Text>
                  <Text>{selectedOrder.quantity}</Text>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text fontWeight="bold">Shipping</Text>
                  <Text>₹{selectedOrder.shippingCharge}</Text>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text fontWeight="bold">Discount</Text>
                  <Text>–₹{selectedOrder.discountAmount}</Text>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text fontWeight="bold">Total</Text>
                  <Text fontWeight="bold">₹{selectedOrder.totalAmount}</Text>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text fontWeight="bold">Shopify Order</Text>
                  <Text>{selectedOrder.shopifyOrderNumber || "Not synced"}</Text>
                </InlineStack>
                <InlineStack align="space-between">
                  <Text fontWeight="bold">OTP Verified</Text>
                  <Badge tone={selectedOrder.otpVerified ? "success" : "critical"}>
                    {selectedOrder.otpVerified ? "Yes" : "No"}
                  </Badge>
                </InlineStack>
                {selectedOrder.isFake && (
                  <Badge tone="warning">⚠ Possible Fake Order: {selectedOrder.fakeReason}</Badge>
                )}
              </BlockStack>
            </Modal.Section>
          </Modal>
        )}

        {toast && (
          <Toast content={toast} onDismiss={() => setToast(null)} duration={3000} />
        )}
      </Page>
    </Frame>
  );
}
