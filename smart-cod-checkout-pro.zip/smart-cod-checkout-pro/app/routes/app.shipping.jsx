import { json } from "@remix-run/node";
import { useLoaderData, useSubmit } from "@remix-run/react";
import {
  Page, Card, DataTable, Button, Modal, TextField, Select, Checkbox,
  BlockStack, InlineStack, Text, Badge, Frame, Toast,
} from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import { prisma } from "../db.server";
import { useState } from "react";

export async function loader({ request }) {
  const { session } = await authenticate.admin(request);
  const rules = await prisma.shippingRule.findMany({
    where: { shop: session.shop },
    orderBy: { isDefault: "desc" },
  });
  return json({ rules });
}

export async function action({ request }) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const body = await request.json();
  const { intent, ruleId, ...data } = body;

  if (intent === "create") {
    await prisma.shippingRule.create({ data: { shop, ...data } });
    return json({ success: true });
  }
  if (intent === "delete") {
    await prisma.shippingRule.delete({ where: { id: ruleId, shop } });
    return json({ success: true });
  }
  if (intent === "set_default") {
    await prisma.shippingRule.updateMany({ where: { shop }, data: { isDefault: false } });
    await prisma.shippingRule.update({ where: { id: ruleId }, data: { isDefault: true } });
    return json({ success: true });
  }

  return json({ error: "Unknown intent" }, { status: 400 });
}

export default function ShippingPage() {
  const { rules } = useLoaderData();
  const submit = useSubmit();
  const [showModal, setShowModal] = useState(false);
  const [toast, setToast] = useState(null);
  const [newRule, setNewRule] = useState({
    name: "",
    type: "flat",
    charge: "0",
    freeAbove: "",
    isDefault: false,
  });

  const updateRule = (k, v) => setNewRule((r) => ({ ...r, [k]: v }));

  const handleCreate = () => {
    submit(
      {
        intent: "create",
        name: newRule.name,
        type: newRule.type,
        charge: parseFloat(newRule.charge) || 0,
        freeAbove: parseFloat(newRule.freeAbove) || null,
        isDefault: newRule.isDefault,
      },
      { method: "post", encType: "application/json" }
    );
    setShowModal(false);
    setToast("Shipping rule created");
  };

  const rows = rules.map((r) => [
    r.name,
    r.type,
    `₹${r.charge}`,
    r.freeAbove ? `₹${r.freeAbove}` : "—",
    <Badge tone={r.isActive ? "success" : "critical"}>{r.isActive ? "Active" : "Inactive"}</Badge>,
    r.isDefault ? <Badge tone="info">Default</Badge> : "—",
    <InlineStack gap="200">
      {!r.isDefault && (
        <Button
          variant="plain"
          onClick={() =>
            submit({ intent: "set_default", ruleId: r.id }, { method: "post", encType: "application/json" })
          }
        >
          Set Default
        </Button>
      )}
      <Button
        variant="plain"
        tone="critical"
        onClick={() =>
          submit({ intent: "delete", ruleId: r.id }, { method: "post", encType: "application/json" })
        }
      >
        Delete
      </Button>
    </InlineStack>,
  ]);

  return (
    <Frame>
      <Page
        title="Shipping Rules"
        primaryAction={{ content: "Add Rule", onAction: () => setShowModal(true) }}
      >
        <Card>
          <DataTable
            columnContentTypes={["text", "text", "numeric", "numeric", "text", "text", "text"]}
            headings={["Name", "Type", "Charge", "Free Above", "Status", "Default", "Actions"]}
            rows={rows}
          />
        </Card>

        <Modal
          open={showModal}
          onClose={() => setShowModal(false)}
          title="Add Shipping Rule"
          primaryAction={{ content: "Create", onAction: handleCreate }}
          secondaryActions={[{ content: "Cancel", onAction: () => setShowModal(false) }]}
        >
          <Modal.Section>
            <BlockStack gap="300">
              <TextField
                label="Rule Name"
                value={newRule.name}
                onChange={(v) => updateRule("name", v)}
                placeholder="Standard Shipping"
              />
              <Select
                label="Rule Type"
                options={[
                  { label: "Flat Rate", value: "flat" },
                  { label: "Free Above Amount", value: "free_above" },
                  { label: "State Based", value: "state_based" },
                  { label: "Free Shipping", value: "free" },
                ]}
                value={newRule.type}
                onChange={(v) => updateRule("type", v)}
              />
              <TextField
                label="Shipping Charge (₹)"
                type="number"
                value={newRule.charge}
                onChange={(v) => updateRule("charge", v)}
              />
              {newRule.type === "free_above" && (
                <TextField
                  label="Free Shipping Above (₹)"
                  type="number"
                  value={newRule.freeAbove}
                  onChange={(v) => updateRule("freeAbove", v)}
                  placeholder="500"
                />
              )}
              <Checkbox
                label="Set as default rule"
                checked={newRule.isDefault}
                onChange={(v) => updateRule("isDefault", v)}
              />
            </BlockStack>
          </Modal.Section>
        </Modal>

        {toast && <Toast content={toast} onDismiss={() => setToast(null)} />}
      </Page>
    </Frame>
  );
}
