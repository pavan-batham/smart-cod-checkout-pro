export async function syncToGoogleSheets({ order, store }) {
  try {
    if (!store.googleSheetsId || !store.googleSheetsCredentials) return;

    const { google } = await import("googleapis");

    const credentials = JSON.parse(store.googleSheetsCredentials);
    const auth = new google.auth.GoogleAuth({
      credentials,
      scopes: ["https://www.googleapis.com/auth/spreadsheets"],
    });

    const sheets = google.sheets({ version: "v4", auth });
    const spreadsheetId = store.googleSheetsId;

    // Check if header row exists
    const headerCheck = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: "Sheet1!A1:R1",
    });

    if (!headerCheck.data.values || headerCheck.data.values.length === 0) {
      // Add headers
      await sheets.spreadsheets.values.update({
        spreadsheetId,
        range: "Sheet1!A1",
        valueInputOption: "RAW",
        resource: {
          values: [[
            "Order ID", "Date", "Customer Name", "Phone", "Email",
            "Address", "City", "State", "Pincode", "Product",
            "Variant", "Quantity", "Price", "Shipping", "Discount",
            "Total", "Status", "Shopify Order #",
          ]],
        },
      });
    }

    // Append the order row
    await sheets.spreadsheets.values.append({
      spreadsheetId,
      range: "Sheet1!A:R",
      valueInputOption: "RAW",
      insertDataOption: "INSERT_ROWS",
      resource: {
        values: [[
          order.id,
          new Date(order.createdAt).toLocaleString("en-IN"),
          order.name,
          order.phone,
          order.email || "",
          order.address,
          order.city,
          order.state,
          order.pincode,
          order.productTitle,
          order.variantTitle || "",
          order.quantity,
          order.productPrice,
          order.shippingCharge,
          order.discountAmount,
          order.totalAmount,
          order.status,
          order.shopifyOrderNumber || "",
        ]],
      },
    });

    // Mark as synced
    const { prisma } = await import("../db.server.js");
    await prisma.codOrder.update({
      where: { id: order.id },
      data: { sheetsSynced: true },
    });

    console.log("Google Sheets synced for order:", order.id);
  } catch (err) {
    console.error("Google Sheets sync failed:", err.message);
  }
}
