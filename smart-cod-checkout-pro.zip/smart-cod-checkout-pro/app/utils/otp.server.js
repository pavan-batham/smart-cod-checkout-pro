import { prisma } from "../db.server.js";

function generateOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

export async function sendOtp({ shop, phone, store }) {
  const code = generateOtp();

  // Log OTP
  await prisma.otpLog.create({
    data: {
      shop,
      phone,
      code,
      expiresAt: new Date(Date.now() + 10 * 60 * 1000),
    },
  });

  const message = `Your Smart COD verification code is: ${code}. Valid for 10 minutes. Do not share with anyone.`;

  try {
    if (store.otpProvider === "twilio" && store.otpApiKey) {
      // Twilio format: accountSid:authToken:fromNumber
      const [accountSid, authToken, fromNumber] = store.otpApiKey.split(":");
      const { default: twilio } = await import("twilio");
      const client = twilio(accountSid, authToken);
      await client.messages.create({
        body: message,
        from: fromNumber,
        to: phone,
      });
    } else if (store.otpProvider === "msg91" && store.otpApiKey) {
      const { default: axios } = await import("axios");
      await axios.post("https://api.msg91.com/api/v5/otp", {
        template_id: "YOUR_TEMPLATE_ID",
        mobile: phone.replace(/\D/g, ""),
        authkey: store.otpApiKey,
        otp: code,
      });
    } else if (store.otpProvider === "fast2sms" && store.otpApiKey) {
      const { default: axios } = await import("axios");
      await axios.post(
        "https://www.fast2sms.com/dev/bulkV2",
        {
          route: "otp",
          variables_values: code,
          numbers: phone.replace(/\D/g, ""),
        },
        { headers: { authorization: store.otpApiKey } }
      );
    } else {
      // Development: log the OTP
      console.log(`[DEV] OTP for ${phone}: ${code}`);
    }
  } catch (err) {
    console.error("OTP send failed:", err.message);
    // Still return the code so we can verify it
  }

  return { code };
}
