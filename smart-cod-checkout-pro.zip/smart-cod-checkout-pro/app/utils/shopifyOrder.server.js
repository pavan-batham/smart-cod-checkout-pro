import { prisma } from "../db.server.js";

export async function createShopifyOrder({ shop, order }) {
  // Get the store's access token
  const session = await prisma.session.findFirst({
    where: { shop, isOnline: false },
    orderBy: { id: "desc" },
  });

  if (!session?.accessToken) {
    throw new Error("No valid session found for shop: " + shop);
  }

  const apiVersion = "2024-04";
  const url = `https://${shop}/admin/api/${apiVersion}/orders.json`;

  const nameParts = order.name.trim().split(" ");
  const firstName = nameParts[0] || order.name;
  const lastName = nameParts.slice(1).join(" ") || "-";

  const payload = {
    order: {
      line_items: [
        {
          variant_id: order.variantId
            ? order.variantId.replace("gid://shopify/ProductVariant/", "")
            : undefined,
          product_id: order.productId
            ? order.productId.replace("gid://shopify/Product/", "")
            : undefined,
          title: order.productTitle,
          quantity: order.quantity,
          price: order.productPrice,
        },
      ],
      shipping_address: {
        first_name: firstName,
        last_name: lastName,
        address1: order.address,
        city: order.city,
        province: order.state,
        zip: order.pincode,
        country: "IN",
        phone: order.phone,
      },
      billing_address: {
        first_name: firstName,
        last_name: lastName,
        address1: order.address,
        city: order.city,
        province: order.state,
        zip: order.pincode,
        country: "IN",
        phone: order.phone,
      },
      customer: {
        first_name: firstName,
        last_name: lastName,
        phone: order.phone,
        ...(order.email ? { email: order.email } : {}),
      },
      financial_status: "pending",
      payment_gateway_names: ["Cash on Delivery"],
      note: order.notes || "",
      note_attributes: [
        { name: "cod_form_order", value: "true" },
        { name: "cod_order_id", value: order.id },
        { name: "otp_verified", value: String(order.otpVerified) },
      ],
      tags: "COD, Smart-COD-Checkout-Pro",
      send_receipt: false,
      send_fulfillment_receipt: false,
      shipping_lines: order.shippingCharge > 0
        ? [
            {
              title: "Cash on Delivery Shipping",
              price: order.shippingCharge,
              code: "COD_SHIPPING",
            },
          ]
        : [],
      discount_codes: order.discountCode && order.discountAmount > 0
        ? [{ code: order.discountCode, amount: order.discountAmount, type: "fixed_amount" }]
        : [],
    },
  };

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Shopify-Access-Token": session.accessToken,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Shopify order creation failed: ${response.status} – ${errorText}`);
  }

  const data = await response.json();
  return {
    id: `gid://shopify/Order/${data.order.id}`,
    name: data.order.name,
    legacyId: data.order.id,
  };
}
