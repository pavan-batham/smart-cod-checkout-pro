export function exportOrdersToCSV(orders) {
  const headers = [
    "Order ID", "Shopify Order #", "Date", "Customer Name", "Phone", "Email",
    "Address", "City", "State", "Pincode", "Product", "Variant",
    "Quantity", "Product Price", "Shipping", "Discount", "Total",
    "Status", "OTP Verified", "Fake Order", "UTM Source", "UTM Campaign",
  ];

  const rows = orders.map((o) => [
    o.id,
    o.shopifyOrderNumber || "",
    new Date(o.createdAt).toLocaleString("en-IN"),
    o.name,
    o.phone,
    o.email || "",
    `"${o.address}"`,
    o.city,
    o.state,
    o.pincode,
    `"${o.productTitle}"`,
    o.variantTitle || "",
    o.quantity,
    o.productPrice,
    o.shippingCharge,
    o.discountAmount,
    o.totalAmount,
    o.status,
    o.otpVerified ? "Yes" : "No",
    o.isFake ? "Yes" : "No",
    o.utmSource || "",
    o.utmCampaign || "",
  ]);

  const csvContent = [
    headers.join(","),
    ...rows.map((row) => row.join(",")),
  ].join("\n");

  return csvContent;
}
