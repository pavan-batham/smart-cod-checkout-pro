/**
 * Detects potentially fake or fraudulent COD orders
 */
export async function detectFakeOrder({ phone, email, store, ipAddress }) {
  if (!store.fakeOrderDetection) {
    return { isFake: false, reason: null };
  }

  // Check blocked phones
  if (store.blockedPhones && phone) {
    const cleanPhone = phone.replace(/\D/g, "");
    const blockedClean = (store.blockedPhones || []).map((p) => p.replace(/\D/g, ""));
    if (blockedClean.includes(cleanPhone)) {
      return { isFake: true, reason: "Phone number is blocked" };
    }
  }

  // Check blocked emails
  if (store.blockedEmails && email) {
    const lowerEmail = email.toLowerCase().trim();
    const blockedEmails = (store.blockedEmails || []).map((e) => e.toLowerCase().trim());
    if (blockedEmails.includes(lowerEmail)) {
      return { isFake: true, reason: "Email address is blocked" };
    }
  }

  // Check for test/fake patterns
  const fakePhonePatterns = [
    /^[0-9]\1{9}$/, // all same digit: 1111111111
    /^1234567890$/,
    /^0000000000$/,
    /^9999999999$/,
  ];

  const cleanPhone = phone?.replace(/\D/g, "") || "";
  for (const pattern of fakePhonePatterns) {
    if (pattern.test(cleanPhone)) {
      return { isFake: true, reason: "Phone number matches fake pattern" };
    }
  }

  // Check for obviously fake names
  const fakeNames = ["test", "testing", "asdf", "qwerty", "abc", "xyz", "fake", "dummy"];
  const lowerName = (phone || "").toLowerCase();
  // We use phone here but would pass name normally

  // IP-based check (rate limiting) — simplified
  // In production, use Redis or a proper rate limiter
  const { prisma } = await import("../db.server.js");
  if (ipAddress) {
    const recentFromIp = await prisma.codOrder.count({
      where: {
        shop: store.shop,
        ipAddress,
        createdAt: { gte: new Date(Date.now() - 60 * 60 * 1000) }, // last 1 hour
      },
    });
    if (recentFromIp >= 5) {
      return { isFake: true, reason: "Too many orders from this IP address" };
    }
  }

  // Check duplicate phone within 1 hour
  const recentFromPhone = await (await import("../db.server.js")).prisma.codOrder.count({
    where: {
      shop: store.shop,
      phone,
      createdAt: { gte: new Date(Date.now() - 60 * 60 * 1000) },
    },
  });

  if (recentFromPhone >= 3) {
    return { isFake: true, reason: "Multiple orders from same phone in short time" };
  }

  return { isFake: false, reason: null };
}
