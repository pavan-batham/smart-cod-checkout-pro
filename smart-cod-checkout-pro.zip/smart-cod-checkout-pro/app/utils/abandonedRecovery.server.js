/**
 * Abandoned COD Order Recovery
 * Sends WhatsApp/SMS/Email reminders for pending COD orders
 * Run via cron: node -e "import('./app/utils/abandonedRecovery.server.js').then(m => m.runAbandonedRecovery())"
 */

import { db } from "../db.server.js";
import { sendNotifications } from "./notifications.server.js";

const RECOVERY_WINDOWS = [
  { hoursAfter: 1, label: "1hr" },
  { hoursAfter: 6, label: "6hr" },
  { hoursAfter: 24, label: "24hr" },
];

export async function runAbandonedRecovery() {
  console.log("[AbandonedRecovery] Starting recovery job...");

  for (const window of RECOVERY_WINDOWS) {
    const windowStart = new Date(Date.now() - (window.hoursAfter + 0.5) * 3600000);
    const windowEnd = new Date(Date.now() - window.hoursAfter * 3600000);

    const abandonedOrders = await db.codOrder.findMany({
      where: {
        status: "PENDING",
        createdAt: { gte: windowStart, lte: windowEnd },
        recoveryAttempts: { lt: RECOVERY_WINDOWS.length },
      },
      include: { store: true },
    });

    console.log(`[AbandonedRecovery] ${window.label} window: ${abandonedOrders.length} orders`);

    for (const order of abandonedOrders) {
      try {
        await sendRecoveryMessage(order, window.label);
        await db.codOrder.update({
          where: { id: order.id },
          data: { recoveryAttempts: { increment: 1 }, lastRecoveryAt: new Date() },
        });
      } catch (err) {
        console.error(`[AbandonedRecovery] Failed for order ${order.id}:`, err.message);
      }
    }
  }

  console.log("[AbandonedRecovery] Done.");
}

async function sendRecoveryMessage(order, windowLabel) {
  const store = order.store;
  const productName = order.productTitle || "your selected item";
  const amount = `Rs. ${order.totalAmount}`;

  const whatsappMsg = `Hi ${order.customerName}! 👋\n\nYou left ${productName} (${amount}) in your cart.\n\nComplete your Cash on Delivery order now and get it delivered to your doorstep!\n\nShop: ${store.shopDomain}`;

  const smsMsg = `Hi ${order.customerName}, complete your COD order for ${productName} (${amount}). Visit ${store.shopDomain} - Team`;

  const emailSubject = `Complete your order - ${productName}`;
  const emailHtml = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>You left something behind!</h2>
      <p>Hi ${order.customerName},</p>
      <p>You were about to order <strong>${productName}</strong> for <strong>${amount}</strong> via Cash on Delivery.</p>
      <p>Complete your order now and get it delivered to your doorstep.</p>
      <a href="https://${store.shopDomain}" style="background:#ff6b35;color:#fff;padding:12px 24px;border-radius:6px;text-decoration:none;display:inline-block;margin:16px 0;">
        Complete My Order
      </a>
      <p style="color:#666;font-size:12px;">This is a reminder from ${store.shopDomain}</p>
    </div>
  `;

  if (store.whatsappEnabled && store.whatsappApiKey && order.customerPhone) {
    await sendWhatsAppRecovery(store, order.customerPhone, whatsappMsg);
  }

  if (store.smsEnabled && order.customerPhone) {
    await sendSmsRecovery(store, order.customerPhone, smsMsg);
  }

  if (store.emailEnabled && store.smtpHost && order.customerEmail) {
    await sendNotifications(store, {
      customerEmail: order.customerEmail,
      customerName: order.customerName,
      subject: emailSubject,
      htmlBody: emailHtml,
      skipMerchant: true,
    });
  }
}

async function sendWhatsAppRecovery(store, phone, message) {
  if (!store.whatsappApiUrl) return;
  try {
    const { default: axios } = await import("axios");
    await axios.post(store.whatsappApiUrl, {
      token: store.whatsappApiKey,
      to: phone.replace(/\D/g, ""),
      body: message,
    });
    console.log(`[AbandonedRecovery] WhatsApp sent to ${phone}`);
  } catch (e) {
    console.error("[AbandonedRecovery] WhatsApp error:", e.message);
  }
}

async function sendSmsRecovery(store, phone, message) {
  try {
    const { default: axios } = await import("axios");
    await axios.get("https://www.fast2sms.com/dev/bulkV2", {
      params: {
        authorization: store.smsApiKey || process.env.FAST2SMS_API_KEY,
        message,
        language: "english",
        route: "q",
        numbers: phone.replace(/\D/g, ""),
      },
    });
    console.log(`[AbandonedRecovery] SMS sent to ${phone}`);
  } catch (e) {
    console.error("[AbandonedRecovery] SMS error:", e.message);
  }
}
