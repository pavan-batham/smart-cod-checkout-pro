import nodemailer from "nodemailer";

export async function sendNotifications({ order, store }) {
  const promises = [];

  if (store.emailEnabled && store.emailSmtpHost) {
    promises.push(sendEmailNotification({ order, store }));
  }

  if (store.smsEnabled && store.otpApiKey) {
    promises.push(sendSmsNotification({ order, store }));
  }

  if (store.whatsappEnabled && store.whatsappNumber) {
    promises.push(sendWhatsAppNotification({ order, store }));
  }

  await Promise.allSettled(promises);
}

async function sendEmailNotification({ order, store }) {
  try {
    const transporter = nodemailer.createTransporter({
      host: store.emailSmtpHost,
      port: store.emailSmtpPort || 587,
      secure: store.emailSmtpPort === 465,
      auth: {
        user: store.emailSmtpUser,
        pass: store.emailSmtpPass,
      },
    });

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #FF6B00; color: white; padding: 20px; text-align: center;">
          <h1>New COD Order Received!</h1>
        </div>
        <div style="padding: 20px; background: #fff;">
          <h2>Order Details</h2>
          <table style="width: 100%; border-collapse: collapse;">
            <tr><td style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold;">Customer</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.name}</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold;">Phone</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.phone}</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold;">Address</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.address}, ${order.city}, ${order.state} - ${order.pincode}</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold;">Product</td><td style="padding: 8px; border-bottom: 1px solid #eee;">${order.productTitle} × ${order.quantity}</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold;">Shipping</td><td style="padding: 8px; border-bottom: 1px solid #eee;">₹${order.shippingCharge}</td></tr>
            <tr><td style="padding: 8px; font-weight: bold; font-size: 18px;">Total</td><td style="padding: 8px; font-size: 18px; color: #FF6B00; font-weight: bold;">₹${order.totalAmount}</td></tr>
          </table>
          ${order.notes ? `<p><strong>Notes:</strong> ${order.notes}</p>` : ""}
        </div>
        <div style="background: #f5f5f5; padding: 15px; text-align: center; color: #666; font-size: 12px;">
          Powered by Smart COD Checkout Pro
        </div>
      </div>
    `;

    await transporter.sendMail({
      from: store.emailFrom || store.emailSmtpUser,
      to: store.emailFrom || store.emailSmtpUser,
      subject: `New COD Order: ${order.name} – ₹${order.totalAmount}`,
      html,
    });

    // Send confirmation to customer if email provided
    if (order.email) {
      await transporter.sendMail({
        from: store.emailFrom || store.emailSmtpUser,
        to: order.email,
        subject: "Your order has been placed! 🎉",
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: #FF6B00; color: white; padding: 20px; text-align: center;">
              <h1>Order Confirmed!</h1>
            </div>
            <div style="padding: 20px;">
              <p>Hi ${order.name},</p>
              <p>Your order has been placed successfully. Our team will call you shortly to confirm delivery.</p>
              <p><strong>Product:</strong> ${order.productTitle}</p>
              <p><strong>Amount to pay:</strong> ₹${order.totalAmount} (Cash on Delivery)</p>
              <p><strong>Delivery address:</strong> ${order.address}, ${order.city}, ${order.state} - ${order.pincode}</p>
            </div>
          </div>
        `,
      });
    }

    console.log("Email notification sent");
  } catch (err) {
    console.error("Email notification failed:", err.message);
  }
}

async function sendSmsNotification({ order, store }) {
  try {
    const message = `New COD Order! Customer: ${order.name}, Phone: ${order.phone}, Product: ${order.productTitle} x${order.quantity}, Amount: Rs.${order.totalAmount}`;

    if (store.otpProvider === "fast2sms") {
      const { default: axios } = await import("axios");
      await axios.post(
        "https://www.fast2sms.com/dev/bulkV2",
        {
          route: "q",
          message,
          language: "english",
          numbers: store.whatsappNumber?.replace(/\D/g, ""),
        },
        { headers: { authorization: store.otpApiKey } }
      );
    }
    // Add more providers as needed
    console.log("SMS notification sent");
  } catch (err) {
    console.error("SMS notification failed:", err.message);
  }
}

async function sendWhatsAppNotification({ order, store }) {
  try {
    // Integration with WhatsApp Business API
    // This is a generic implementation — works with most WhatsApp BSPs
    const message = `🛍️ *New COD Order!*\n\n*Customer:* ${order.name}\n*Phone:* ${order.phone}\n*Product:* ${order.productTitle} x${order.quantity}\n*Amount:* ₹${order.totalAmount}\n*Address:* ${order.address}, ${order.city}, ${order.state} - ${order.pincode}${order.notes ? `\n*Notes:* ${order.notes}` : ""}`;

    // Use WhatsApp Web API (unofficial) or official BSP
    // Placeholder — merchant configures their WhatsApp gateway
    console.log("WhatsApp message queued:", message);
  } catch (err) {
    console.error("WhatsApp notification failed:", err.message);
  }
}
