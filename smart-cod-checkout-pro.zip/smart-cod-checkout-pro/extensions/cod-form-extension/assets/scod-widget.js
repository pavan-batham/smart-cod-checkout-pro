/**
 * Smart COD Checkout Pro - Storefront Widget
 * Version: 1.0.0
 * This file is loaded on the merchant's storefront and handles:
 * - Replacing Add to Cart / Buy Now buttons
 * - Rendering the COD popup/embedded form
 * - Submitting orders to the app backend
 * - OTP verification
 * - Pixel tracking
 */

(function (window, document) {
  "use strict";

  const SCOD = window.SCOD || {};
  window.SCOD = SCOD;

  // ─── Config (injected by App Embed Block) ──────────────────────────────────
  SCOD.config = window.SCODConfig || {};
  SCOD.appUrl = SCOD.config.appUrl || "";
  SCOD.shop = SCOD.config.shop || Shopify?.shop || "";

  // ─── State ─────────────────────────────────────────────────────────────────
  SCOD.state = {
    formConfig: null,
    currentProduct: null,
    selectedVariant: null,
    quantity: 1,
    isOpen: false,
    isSubmitting: false,
    pendingOrderId: null,
    otpRequired: false,
  };

  // ─── Indian States ──────────────────────────────────────────────────────────
  const INDIAN_STATES = [
    "Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh",
    "Goa","Gujarat","Haryana","Himachal Pradesh","Jharkhand","Karnataka",
    "Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram",
    "Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana",
    "Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Andaman and Nicobar Islands",
    "Chandigarh","Delhi","Jammu and Kashmir","Ladakh","Lakshadweep","Puducherry",
  ];

  // ─── Fetch Form Config ──────────────────────────────────────────────────────
  SCOD.loadFormConfig = async function (productId) {
    try {
      const url = `${SCOD.appUrl}/api/form-config?shop=${encodeURIComponent(SCOD.shop)}&productId=${encodeURIComponent(productId)}`;
      const res = await fetch(url);
      const data = await res.json();
      SCOD.state.formConfig = data.form;
      SCOD.tracking = data.tracking || {};
      return data.form;
    } catch (err) {
      console.error("[SCOD] Failed to load form config:", err);
      return null;
    }
  };

  // ─── Get Product Data from Page ─────────────────────────────────────────────
  SCOD.getProductData = function () {
    try {
      const meta = document.querySelector("meta[name='product-id']");
      const productId = meta?.content ||
        window.ShopifyAnalytics?.meta?.product?.id ||
        document.querySelector("[data-product-id]")?.dataset?.productId;

      const titleEl = document.querySelector(".product__title, .product-title, h1.title, [itemprop='name']");
      const priceEl = document.querySelector(".price__regular .price-item--regular, .product__price, [class*='price']");

      const priceText = priceEl?.textContent?.replace(/[^0-9.]/g, "") || "0";
      const price = parseFloat(priceText);

      return {
        id: productId ? `gid://shopify/Product/${productId}` : null,
        legacyId: productId,
        title: titleEl?.textContent?.trim() || document.title,
        price: isNaN(price) ? 0 : price,
      };
    } catch {
      return null;
    }
  };

  SCOD.getSelectedVariant = function () {
    try {
      const variantInput = document.querySelector('[name="id"]');
      const variantId = variantInput?.value;
      if (!variantId) return null;

      return {
        id: `gid://shopify/ProductVariant/${variantId}`,
        legacyId: variantId,
        title: document.querySelector(".product__variant-title, [class*='variant-title']")?.textContent?.trim() || "",
        price: parseFloat(document.querySelector(".price__regular .price-item--regular, [class*='price']")?.textContent?.replace(/[^0-9.]/g, "") || "0"),
      };
    } catch {
      return null;
    }
  };

  SCOD.getQuantity = function () {
    const input = document.querySelector('[name="quantity"], input[type="number"][class*="qty"], input[type="number"][class*="quantity"]');
    return parseInt(input?.value || "1") || 1;
  };

  // ─── UTM Params ─────────────────────────────────────────────────────────────
  SCOD.getUtmParams = function () {
    const params = new URLSearchParams(window.location.search);
    return {
      utmSource: params.get("utm_source"),
      utmMedium: params.get("utm_medium"),
      utmCampaign: params.get("utm_campaign"),
    };
  };

  // ─── Inject Buttons ─────────────────────────────────────────────────────────
  SCOD.injectButtons = function (formConfig) {
    if (!formConfig) return;

    const btnStyle = `
      background-color: ${formConfig.btnBgColor};
      color: ${formConfig.btnTextColor};
      border: none;
      border-radius: ${formConfig.btnBorderRadius}px;
      font-size: ${formConfig.btnFontSize}px;
      padding: 14px 24px;
      cursor: pointer;
      font-weight: 600;
      letter-spacing: 0.3px;
      width: ${formConfig.btnFullWidth ? "100%" : "auto"};
      display: block;
      margin-top: 12px;
      font-family: ${formConfig.fontFamily || "inherit"};
      transition: opacity 0.2s ease, transform 0.1s ease;
    `;

    const btnText = `${formConfig.showCartIcon ? "🛒 " : ""}${formConfig.btnText}`;

    // Find form elements to inject into
    const productForm = document.querySelector("form[action='/cart/add']");
    if (!productForm) return;

    // Create COD button
    const codBtn = document.createElement("button");
    codBtn.type = "button";
    codBtn.id = "scod-main-btn";
    codBtn.innerHTML = btnText;
    codBtn.setAttribute("style", btnStyle);

    codBtn.addEventListener("mouseenter", () => { codBtn.style.opacity = "0.9"; });
    codBtn.addEventListener("mouseleave", () => { codBtn.style.opacity = "1"; });
    codBtn.addEventListener("mousedown", () => { codBtn.style.transform = "scale(0.98)"; });
    codBtn.addEventListener("mouseup", () => { codBtn.style.transform = "scale(1)"; });

    codBtn.addEventListener("click", () => {
      SCOD.state.selectedVariant = SCOD.getSelectedVariant();
      SCOD.state.quantity = SCOD.getQuantity();
      SCOD.openForm();
    });

    // Insert after the native Add to Cart button
    const addToCartBtn = productForm.querySelector('[name="add"], [type="submit"], button[class*="add-to-cart"]');
    if (addToCartBtn) {
      addToCartBtn.parentNode.insertBefore(codBtn, addToCartBtn.nextSibling);
    } else {
      productForm.appendChild(codBtn);
    }
  };

  // ─── Build Form HTML ────────────────────────────────────────────────────────
  SCOD.buildFormHtml = function (product) {
    const cfg = SCOD.state.formConfig;
    if (!cfg) return "";

    const variant = SCOD.state.selectedVariant;
    const productPrice = variant?.price || product?.price || 0;
    const fields = Array.isArray(cfg.fields) ? cfg.fields.filter((f) => f.enabled) : [];

    const stateOptions = INDIAN_STATES.map(
      (s) => `<option value="${s}">${s}</option>`
    ).join("");

    const fieldHtml = fields.map((field) => {
      const required = field.required ? "required" : "";
      const placeholder = field.placeholder || field.label;

      if (field.type === "select_state") {
        return `
          <div class="scod-field">
            <label class="scod-label">${field.label}${field.required ? ' <span class="scod-req">*</span>' : ""}</label>
            <select name="${field.id}" class="scod-input scod-select" ${required}>
              <option value="">Select State</option>
              ${stateOptions}
            </select>
          </div>`;
      }

      if (field.type === "textarea") {
        return `
          <div class="scod-field">
            <label class="scod-label">${field.label}${field.required ? ' <span class="scod-req">*</span>' : ""}</label>
            <textarea name="${field.id}" class="scod-input scod-textarea" placeholder="${placeholder}" ${required}></textarea>
          </div>`;
      }

      return `
        <div class="scod-field">
          <label class="scod-label">${field.label}${field.required ? ' <span class="scod-req">*</span>' : ""}</label>
          <input type="${field.type === "phone" ? "tel" : field.type || "text"}" name="${field.id}" class="scod-input" placeholder="${placeholder}" ${required} />
        </div>`;
    }).join("");

    const quantityHtml = cfg.showQuantity ? `
      <div class="scod-field scod-qty-field">
        <label class="scod-label">Quantity</label>
        <div class="scod-qty-wrap">
          <button type="button" class="scod-qty-btn" id="scod-qty-minus">−</button>
          <input type="number" id="scod-qty-input" class="scod-input scod-qty-input" value="${SCOD.state.quantity}" min="${cfg.minQuantity || 1}" max="${cfg.maxQuantity || 10}" readonly />
          <button type="button" class="scod-qty-btn" id="scod-qty-plus">+</button>
        </div>
      </div>` : "";

    const discountHtml = cfg.discountEnabled ? `
      <div class="scod-field">
        <label class="scod-label">Discount Code (optional)</label>
        <div class="scod-discount-wrap">
          <input type="text" id="scod-discount-code" class="scod-input" placeholder="Enter coupon code" />
          <button type="button" id="scod-apply-discount" class="scod-discount-btn">Apply</button>
        </div>
        <p id="scod-discount-msg" class="scod-discount-msg" style="display:none"></p>
      </div>` : "";

    const totalHtml = `
      <div class="scod-summary">
        <div class="scod-summary-row">
          <span>Product</span>
          <span id="scod-summary-product">₹${productPrice.toLocaleString("en-IN")}</span>
        </div>
        <div class="scod-summary-row" id="scod-shipping-row">
          <span>Shipping</span>
          <span id="scod-summary-shipping">Calculating...</span>
        </div>
        <div class="scod-summary-row" id="scod-discount-row" style="display:none; color: #00A36C;">
          <span>Discount</span>
          <span id="scod-summary-discount">–₹0</span>
        </div>
        <div class="scod-summary-total">
          <span>Total (COD)</span>
          <span id="scod-summary-total">₹${productPrice.toLocaleString("en-IN")}</span>
        </div>
      </div>`;

    const trustHtml = cfg.trustBadges ? `
      <div class="scod-trust">
        <span>🔒 Secure</span>
        <span>💵 Cash on Delivery</span>
        <span>↩ Easy Returns</span>
      </div>` : "";

    const urgencyHtml = cfg.urgencyText ? `
      <div class="scod-urgency">${cfg.urgencyText}</div>` : "";

    return `
      <div class="scod-form-inner" style="background:${cfg.formBgColor};color:${cfg.formTextColor};font-family:${cfg.fontFamily}">
        <div class="scod-form-header">
          ${cfg.logoUrl ? `<img src="${cfg.logoUrl}" alt="${cfg.brandName || "logo"}" class="scod-logo" />` : ""}
          <div class="scod-form-title">${cfg.formTitle}</div>
          <button type="button" class="scod-close" id="scod-close-btn">✕</button>
        </div>

        <div class="scod-product-info">
          <div class="scod-product-title">${product?.title || ""}</div>
          ${variant?.title ? `<div class="scod-variant-title">${variant.title}</div>` : ""}
        </div>

        ${urgencyHtml}

        <form id="scod-order-form" novalidate>
          ${fieldHtml}
          ${quantityHtml}
          ${discountHtml}
          ${totalHtml}

          <button type="submit" id="scod-submit-btn" style="background:${cfg.accentColor};color:#fff;border:none;border-radius:${cfg.btnBorderRadius}px;font-size:16px;padding:15px;width:100%;cursor:pointer;font-weight:700;margin-top:12px;font-family:${cfg.fontFamily || 'inherit'}">
            ${cfg.showCartIcon ? "🛒 " : ""}Place Order – Cash on Delivery
          </button>

          <p id="scod-error-msg" class="scod-error" style="display:none"></p>
        </form>

        ${trustHtml}

        ${cfg.customCss ? `<style>${cfg.customCss}</style>` : ""}
      </div>

      <!-- OTP Screen (hidden by default) -->
      <div id="scod-otp-screen" style="display:none" class="scod-form-inner" style="background:${cfg.formBgColor}">
        <div class="scod-form-header">
          <div class="scod-form-title">Verify Your Phone</div>
        </div>
        <p class="scod-otp-desc">Enter the 6-digit OTP sent to your phone number.</p>
        <div class="scod-field">
          <label class="scod-label">OTP Code</label>
          <input type="number" id="scod-otp-input" class="scod-input" placeholder="Enter 6-digit OTP" maxlength="6" />
        </div>
        <button type="button" id="scod-verify-otp-btn" style="background:${cfg.accentColor};color:#fff;border:none;border-radius:${cfg.btnBorderRadius}px;font-size:16px;padding:15px;width:100%;cursor:pointer;font-weight:700;margin-top:12px;">
          Verify & Place Order
        </button>
        <p id="scod-otp-error" class="scod-error" style="display:none"></p>
        <p class="scod-otp-resend">Didn't receive OTP? <a href="#" id="scod-resend-otp">Resend</a></p>
      </div>
    `;
  };

  // ─── Inject Styles ──────────────────────────────────────────────────────────
  SCOD.injectStyles = function () {
    if (document.getElementById("scod-styles")) return;
    const style = document.createElement("style");
    style.id = "scod-styles";
    style.textContent = `
      #scod-overlay {
        position: fixed; inset: 0; background: rgba(0,0,0,0.55);
        z-index: 999998; display: flex; align-items: center; justify-content: center;
        padding: 16px; opacity: 0; transition: opacity 0.3s ease;
      }
      #scod-overlay.open { opacity: 1; }
      #scod-modal {
        background: #fff; border-radius: 16px; max-width: 480px; width: 100%;
        max-height: 90vh; overflow-y: auto; box-shadow: 0 24px 80px rgba(0,0,0,0.25);
        transform: translateY(30px) scale(0.96);
        transition: transform 0.3s cubic-bezier(0.34,1.56,0.64,1);
        scrollbar-width: thin;
      }
      #scod-overlay.open #scod-modal { transform: translateY(0) scale(1); }
      .scod-form-inner { padding: 24px; }
      .scod-form-header {
        display: flex; align-items: center; justify-content: space-between;
        margin-bottom: 16px; gap: 12px;
      }
      .scod-form-title { font-size: 18px; font-weight: 700; flex: 1; }
      .scod-logo { height: 36px; object-fit: contain; }
      .scod-close {
        background: #f5f5f5; border: none; border-radius: 50%;
        width: 32px; height: 32px; cursor: pointer; font-size: 16px;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0; color: #555;
      }
      .scod-close:hover { background: #e5e5e5; }
      .scod-product-info { margin-bottom: 12px; }
      .scod-product-title { font-size: 14px; font-weight: 600; }
      .scod-variant-title { font-size: 12px; color: #888; }
      .scod-urgency {
        background: #FFF3CD; color: #856404; padding: 8px 12px;
        border-radius: 8px; font-size: 13px; margin-bottom: 14px;
        border-left: 3px solid #F59E0B;
      }
      .scod-field { margin-bottom: 14px; }
      .scod-label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 5px; }
      .scod-req { color: #e53e3e; }
      .scod-input {
        width: 100%; padding: 10px 12px; border: 1.5px solid #ddd; border-radius: 8px;
        font-size: 14px; outline: none; box-sizing: border-box; transition: border-color 0.2s;
        font-family: inherit; background: #fff; color: inherit;
      }
      .scod-input:focus { border-color: var(--scod-accent, #FF6B00); }
      .scod-textarea { min-height: 80px; resize: vertical; }
      .scod-select { appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23666' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 10px center; padding-right: 36px; }
      .scod-qty-field {}
      .scod-qty-wrap { display: flex; align-items: center; gap: 0; border: 1.5px solid #ddd; border-radius: 8px; overflow: hidden; width: fit-content; }
      .scod-qty-btn { background: #f5f5f5; border: none; padding: 10px 16px; cursor: pointer; font-size: 18px; font-weight: 500; transition: background 0.2s; }
      .scod-qty-btn:hover { background: #e5e5e5; }
      .scod-qty-input { border: none; border-left: 1.5px solid #ddd; border-right: 1.5px solid #ddd; width: 52px; text-align: center; padding: 10px 8px; font-size: 15px; font-weight: 600; outline: none; }
      .scod-discount-wrap { display: flex; gap: 8px; }
      .scod-discount-wrap .scod-input { flex: 1; }
      .scod-discount-btn { padding: 10px 16px; background: #f5f5f5; border: 1.5px solid #ddd; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 600; white-space: nowrap; }
      .scod-discount-msg { font-size: 12px; margin-top: 4px; }
      .scod-summary { background: #f9f9f9; border-radius: 10px; padding: 14px; margin: 16px 0; }
      .scod-summary-row { display: flex; justify-content: space-between; font-size: 13px; padding: 4px 0; color: #555; }
      .scod-summary-total { display: flex; justify-content: space-between; font-size: 17px; font-weight: 700; padding-top: 10px; margin-top: 6px; border-top: 1.5px solid #ddd; }
      .scod-error { color: #e53e3e; font-size: 13px; margin-top: 8px; padding: 8px 12px; background: #fff5f5; border-radius: 6px; border-left: 3px solid #e53e3e; }
      .scod-trust { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; margin-top: 14px; font-size: 12px; color: #666; }
      .scod-otp-desc { font-size: 14px; color: #555; margin-bottom: 16px; }
      .scod-otp-resend { text-align: center; font-size: 13px; color: #888; margin-top: 12px; }
      .scod-otp-resend a { color: var(--scod-accent, #FF6B00); }
      @media (max-width: 480px) {
        #scod-overlay { padding: 0; align-items: flex-end; }
        #scod-modal { border-radius: 20px 20px 0 0; max-height: 95vh; }
      }
    `;
    document.head.appendChild(style);
  };

  // ─── Open Form ──────────────────────────────────────────────────────────────
  SCOD.openForm = function () {
    const product = SCOD.state.currentProduct;
    const cfg = SCOD.state.formConfig;
    if (!cfg || !product) return;

    SCOD.injectStyles();

    let overlay = document.getElementById("scod-overlay");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "scod-overlay";
      overlay.innerHTML = `<div id="scod-modal"></div>`;
      document.body.appendChild(overlay);

      overlay.addEventListener("click", (e) => {
        if (e.target === overlay) SCOD.closeForm();
      });
    }

    const modal = document.getElementById("scod-modal");
    modal.innerHTML = SCOD.buildFormHtml(product);

    // Set CSS variable for accent
    if (cfg.accentColor) {
      modal.style.setProperty("--scod-accent", cfg.accentColor);
    }

    // Bind events
    document.getElementById("scod-close-btn")?.addEventListener("click", SCOD.closeForm);

    // Quantity buttons
    const qtyInput = document.getElementById("scod-qty-input");
    document.getElementById("scod-qty-minus")?.addEventListener("click", () => {
      const min = parseInt(qtyInput?.min || "1");
      SCOD.state.quantity = Math.max(min, SCOD.state.quantity - 1);
      if (qtyInput) qtyInput.value = SCOD.state.quantity;
      SCOD.updateSummary();
    });
    document.getElementById("scod-qty-plus")?.addEventListener("click", () => {
      const max = parseInt(qtyInput?.max || "10");
      SCOD.state.quantity = Math.min(max, SCOD.state.quantity + 1);
      if (qtyInput) qtyInput.value = SCOD.state.quantity;
      SCOD.updateSummary();
    });

    // Discount
    document.getElementById("scod-apply-discount")?.addEventListener("click", SCOD.applyDiscount);

    // Form submit
    document.getElementById("scod-order-form")?.addEventListener("submit", (e) => {
      e.preventDefault();
      SCOD.submitOrder();
    });

    // OTP verify
    document.getElementById("scod-verify-otp-btn")?.addEventListener("click", SCOD.verifyOtp);

    SCOD.loadShippingCharge().then(SCOD.updateSummary);

    requestAnimationFrame(() => overlay.classList.add("open"));
    SCOD.state.isOpen = true;
    document.body.style.overflow = "hidden";

    // Track form view
    SCOD.trackEvent("InitiateCheckout");
  };

  SCOD.closeForm = function () {
    const overlay = document.getElementById("scod-overlay");
    if (overlay) {
      overlay.classList.remove("open");
      setTimeout(() => {
        overlay.remove();
        SCOD.state.isOpen = false;
      }, 300);
    }
    document.body.style.overflow = "";
  };

  // ─── Load Shipping Charge ───────────────────────────────────────────────────
  SCOD.loadShippingCharge = async function () {
    // We'll calculate this server-side on order submit
    // For now, show "Free" or the configured flat rate
    SCOD.state.shippingCharge = 0;
    const el = document.getElementById("scod-summary-shipping");
    if (el) el.textContent = "Calculated at checkout";
    return 0;
  };

  SCOD.updateSummary = function () {
    const cfg = SCOD.state.formConfig;
    const variant = SCOD.state.selectedVariant;
    const product = SCOD.state.currentProduct;
    const price = variant?.price || product?.price || 0;
    const qty = SCOD.state.quantity;
    const shipping = SCOD.state.shippingCharge || 0;
    const discount = SCOD.state.discountAmount || 0;
    const total = price * qty + shipping - discount;

    const fmt = (n) => `₹${n.toLocaleString("en-IN")}`;

    const productEl = document.getElementById("scod-summary-product");
    const shippingEl = document.getElementById("scod-summary-shipping");
    const totalEl = document.getElementById("scod-summary-total");
    const discountRow = document.getElementById("scod-discount-row");
    const discountEl = document.getElementById("scod-summary-discount");

    if (productEl) productEl.textContent = `${fmt(price)} × ${qty} = ${fmt(price * qty)}`;
    if (shippingEl) shippingEl.textContent = shipping === 0 ? "Free" : fmt(shipping);
    if (totalEl) totalEl.textContent = fmt(Math.max(0, total));
    if (discount > 0 && discountRow && discountEl) {
      discountRow.style.display = "flex";
      discountEl.textContent = `–${fmt(discount)}`;
    }
  };

  // ─── Apply Discount ─────────────────────────────────────────────────────────
  SCOD.applyDiscount = function () {
    const cfg = SCOD.state.formConfig;
    const code = document.getElementById("scod-discount-code")?.value?.trim();
    const msgEl = document.getElementById("scod-discount-msg");
    if (!msgEl) return;

    if (!code) {
      msgEl.style.display = "block";
      msgEl.style.color = "#e53e3e";
      msgEl.textContent = "Please enter a discount code";
      return;
    }

    if (cfg.discountCode && code.toUpperCase() === cfg.discountCode.toUpperCase()) {
      const price = SCOD.state.selectedVariant?.price || SCOD.state.currentProduct?.price || 0;
      const qty = SCOD.state.quantity;
      let discount = 0;
      if (cfg.discountType === "percentage") {
        discount = (price * qty * cfg.discountValue) / 100;
      } else {
        discount = cfg.discountValue || 0;
      }
      SCOD.state.discountAmount = discount;
      SCOD.state.appliedDiscountCode = code;
      msgEl.style.color = "#00A36C";
      msgEl.style.display = "block";
      msgEl.textContent = `✓ Discount applied! You save ₹${discount.toLocaleString("en-IN")}`;
      SCOD.updateSummary();
    } else {
      SCOD.state.discountAmount = 0;
      SCOD.state.appliedDiscountCode = null;
      msgEl.style.color = "#e53e3e";
      msgEl.style.display = "block";
      msgEl.textContent = "Invalid discount code";
    }
  };

  // ─── Submit Order ───────────────────────────────────────────────────────────
  SCOD.submitOrder = async function () {
    if (SCOD.state.isSubmitting) return;

    const form = document.getElementById("scod-order-form");
    if (!form) return;

    // Validate
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }

    const errorEl = document.getElementById("scod-error-msg");
    const submitBtn = document.getElementById("scod-submit-btn");

    const formData = new FormData(form);
    const fields = Object.fromEntries(formData.entries());

    const product = SCOD.state.currentProduct;
    const variant = SCOD.state.selectedVariant;
    const utms = SCOD.getUtmParams();

    const payload = {
      shop: SCOD.shop,
      formId: SCOD.state.formConfig?.id,
      name: fields.name || "",
      phone: fields.phone || "",
      email: fields.email || "",
      address: fields.address || "",
      city: fields.city || "",
      state: fields.state || "",
      pincode: fields.pincode || "",
      notes: fields.notes || "",
      productId: product?.id || "",
      productTitle: product?.title || "",
      variantId: variant?.id || null,
      variantTitle: variant?.title || null,
      quantity: SCOD.state.quantity,
      productPrice: variant?.price || product?.price || 0,
      discountCode: SCOD.state.appliedDiscountCode || null,
      ...utms,
    };

    SCOD.state.isSubmitting = true;
    if (submitBtn) {
      submitBtn.textContent = "Placing Order...";
      submitBtn.disabled = true;
    }
    if (errorEl) errorEl.style.display = "none";

    try {
      const res = await fetch(`${SCOD.appUrl}/api/cod-order`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!data.success) {
        throw new Error(data.error || "Order failed. Please try again.");
      }

      if (data.requireOtp) {
        SCOD.state.pendingOrderId = data.orderId;
        // Show OTP screen
        const formScreen = document.getElementById("scod-order-form");
        const otpScreen = document.getElementById("scod-otp-screen");
        if (formScreen) formScreen.style.display = "none";
        if (otpScreen) otpScreen.style.display = "block";
      } else {
        // Success!
        SCOD.onOrderSuccess(data);
      }
    } catch (err) {
      if (errorEl) {
        errorEl.textContent = err.message;
        errorEl.style.display = "block";
      }
      if (submitBtn) {
        submitBtn.textContent = "Place Order – Cash on Delivery";
        submitBtn.disabled = false;
      }
    } finally {
      SCOD.state.isSubmitting = false;
    }
  };

  // ─── Verify OTP ─────────────────────────────────────────────────────────────
  SCOD.verifyOtp = async function () {
    const otp = document.getElementById("scod-otp-input")?.value?.trim();
    const errorEl = document.getElementById("scod-otp-error");
    const verifyBtn = document.getElementById("scod-verify-otp-btn");

    if (!otp || otp.length !== 6) {
      if (errorEl) {
        errorEl.textContent = "Please enter a valid 6-digit OTP";
        errorEl.style.display = "block";
      }
      return;
    }

    if (verifyBtn) {
      verifyBtn.textContent = "Verifying...";
      verifyBtn.disabled = true;
    }
    if (errorEl) errorEl.style.display = "none";

    try {
      const res = await fetch(`${SCOD.appUrl}/api/verify-otp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId: SCOD.state.pendingOrderId, otp }),
      });

      const data = await res.json();

      if (!data.success) {
        throw new Error(data.error || "Verification failed");
      }

      SCOD.onOrderSuccess(data);
    } catch (err) {
      if (errorEl) {
        errorEl.textContent = err.message;
        errorEl.style.display = "block";
      }
      if (verifyBtn) {
        verifyBtn.textContent = "Verify & Place Order";
        verifyBtn.disabled = false;
      }
    }
  };

  // ─── Order Success ──────────────────────────────────────────────────────────
  SCOD.onOrderSuccess = function (data) {
    // Fire pixels
    SCOD.trackPurchase();

    const modal = document.getElementById("scod-modal");
    const cfg = SCOD.state.formConfig;
    const product = SCOD.state.currentProduct;

    if (modal) {
      modal.innerHTML = `
        <div style="padding: 40px; text-align: center;">
          <div style="font-size: 64px; margin-bottom: 16px;">✅</div>
          <h2 style="font-size: 22px; font-weight: 700; margin-bottom: 12px; color: #00A36C;">Order Placed!</h2>
          <p style="font-size: 15px; color: #555; line-height: 1.6;">${data.message || cfg?.successMessage || "Your order has been placed successfully. We'll contact you shortly."}</p>
          <button onclick="SCOD.closeForm()" style="margin-top: 24px; background: #FF6B00; color: #fff; border: none; padding: 12px 32px; border-radius: 8px; font-size: 15px; cursor: pointer; font-weight: 600;">
            Continue Shopping
          </button>
        </div>
      `;
    }

    if (data.redirect) {
      setTimeout(() => {
        window.location.href = data.redirect;
      }, 2000);
    }
  };

  // ─── Pixel Tracking ─────────────────────────────────────────────────────────
  SCOD.trackEvent = function (eventName, data = {}) {
    const tracking = SCOD.tracking || {};

    // Facebook Pixel
    if (tracking.fbPixelId && window.fbq) {
      fbq("track", eventName, data);
    }

    // TikTok Pixel
    if (tracking.tiktokPixelId && window.ttq) {
      ttq.track(eventName, data);
    }

    // Google Analytics
    if (tracking.gaTrackingId && window.gtag) {
      gtag("event", eventName, data);
    }
  };

  SCOD.trackPurchase = function () {
    const product = SCOD.state.currentProduct;
    const variant = SCOD.state.selectedVariant;
    const price = variant?.price || product?.price || 0;
    const qty = SCOD.state.quantity;
    const total = price * qty;

    SCOD.trackEvent("Purchase", {
      value: total,
      currency: "INR",
      content_type: "product",
      content_ids: [product?.legacyId],
      content_name: product?.title,
      num_items: qty,
    });
  };

  // ─── Initialize ─────────────────────────────────────────────────────────────
  SCOD.init = async function () {
    const product = SCOD.getProductData();
    if (!product || !product.legacyId) return;

    SCOD.state.currentProduct = product;
    SCOD.state.quantity = SCOD.getQuantity();

    const formConfig = await SCOD.loadFormConfig(product.legacyId);
    if (!formConfig) return;

    SCOD.injectButtons(formConfig);

    // Auto-trigger
    if (formConfig.triggerType === "auto") {
      setTimeout(SCOD.openForm, 2000);
    } else if (formConfig.triggerType === "exit_intent") {
      document.addEventListener("mouseleave", (e) => {
        if (e.clientY <= 0 && !SCOD.state.isOpen) {
          SCOD.openForm();
        }
      }, { once: true });
    }

    // Listen for variant changes
    document.addEventListener("change", (e) => {
      if (e.target.name === "id") {
        SCOD.state.selectedVariant = SCOD.getSelectedVariant();
        SCOD.state.quantity = SCOD.getQuantity();
      }
    });
  };

  // ─── Auto-init on DOMContentLoaded ──────────────────────────────────────────
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", SCOD.init);
  } else {
    SCOD.init();
  }
})(window, document);
