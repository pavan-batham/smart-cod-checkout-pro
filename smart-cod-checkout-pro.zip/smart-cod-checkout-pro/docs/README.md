# Smart COD Checkout Pro
### Production-Ready Shopify COD App — Complete Source Code

---

## 🚀 Overview

Smart COD Checkout Pro is a premium Shopify app that replaces the default Add to Cart / Buy Now buttons with fully customizable Cash on Delivery order forms. Built for Indian D2C brands to maximize conversions and automate order management.

**Competes directly with:** CodForm, EasyCOD, CashKaro COD, and other premium COD apps.

---

## ✨ Features

| Category | Features |
|---|---|
| **Forms** | Popup & embedded layouts, drag-and-drop builder, multiple templates, product/variant targeting |
| **Order Flow** | Auto Shopify order creation, OTP verification, fake order detection, discount codes, shipping rules |
| **Notifications** | WhatsApp, SMS (Fast2SMS/Twilio), Email (SMTP), abandoned order recovery |
| **Integrations** | Google Sheets sync, Facebook Pixel, TikTok Pixel, Google Analytics |
| **Analytics** | Dashboard, order stats, revenue reports, funnel tracking, export (CSV/Excel) |
| **Multi-language** | English, Hindi, Marathi, Tamil, Telugu, Bengali |
| **Admin UI** | Shopify Polaris, App Bridge, responsive design |
| **Billing** | Free/Basic($9.99)/Pro($24.99) via Shopify Billing API |
| **Compliance** | GDPR webhooks, data redaction, secure OAuth |

---

## 📁 Project Structure

```
smart-cod-checkout-pro/
├── app/
│   ├── routes/
│   │   ├── app._index.jsx          # Dashboard
│   │   ├── app.forms._index.jsx    # Forms list
│   │   ├── app.forms.$id.jsx       # Form builder (7 tabs)
│   │   ├── app.orders._index.jsx   # Orders management
│   │   ├── app.analytics.jsx       # Analytics
│   │   ├── app.settings.jsx        # Settings (6 tabs)
│   │   ├── app.billing.jsx         # Subscription plans
│   │   ├── app.shipping.jsx        # Shipping rules
│   │   ├── api.cod-order.jsx       # POST: Create COD order
│   │   ├── api.verify-otp.jsx      # POST: Verify OTP
│   │   ├── api.form-config.jsx     # GET: Storefront config
│   │   ├── webhooks.jsx            # Shopify webhooks
│   │   ├── webhooks.gdpr.jsx       # GDPR webhooks (required)
│   │   └── health.jsx              # Health check endpoint
│   ├── utils/
│   │   ├── abandonedRecovery.server.js
│   │   ├── export.server.js
│   │   ├── fakeOrderDetection.server.js
│   │   ├── i18n.js
│   │   ├── notifications.server.js
│   │   ├── otp.server.js
│   │   ├── sheets.server.js
│   │   └── shopifyOrder.server.js
│   ├── db.server.js
│   ├── root.jsx
│   └── shopify.server.js
├── extensions/
│   └── cod-form-extension/
│       ├── assets/scod-widget.js   # Storefront JS widget
│       ├── blocks/app-embed.liquid # Theme embed block
│       └── shopify.extension.toml
├── prisma/
│   ├── schema.prisma               # Full DB schema
│   └── migrations/
├── docs/
│   └── README.md                   # This file
├── cron.js                         # Scheduled jobs
├── Dockerfile
├── docker-compose.yml
├── fly.toml
├── shopify.app.toml
├── package.json
└── vite.config.ts
```

---

## 🛠 Tech Stack

| Layer | Technology |
|---|---|
| Framework | Remix v2 + Vite |
| Runtime | Node.js 18+ |
| Admin UI | Shopify Polaris v12 + App Bridge v4 |
| Database | PostgreSQL + Prisma ORM v5 |
| Shopify SDK | @shopify/shopify-app-remix v3 |
| Notifications | Nodemailer + Twilio + Fast2SMS |
| Integrations | Google Sheets API v4 |
| Deployment | Fly.io / Railway / Render |

---

## 🔧 Installation & Setup

### 1. Prerequisites

```bash
node --version   # Must be >= 18.20
npm --version    # Must be >= 9
```

Install Shopify CLI:
```bash
npm install -g @shopify/cli@latest
```

### 2. Clone & Install Dependencies

```bash
git clone <your-repo>
cd smart-cod-checkout-pro
npm install
```

### 3. Environment Variables

Copy `.env.example` to `.env` and fill in values:

```env
SHOPIFY_API_KEY=your_api_key_here
SHOPIFY_API_SECRET=your_api_secret_here
SHOPIFY_APP_URL=https://your-app-domain.fly.dev
SCOPES=write_orders,read_products,write_products,read_customers,write_customers
DATABASE_URL=postgresql://user:password@localhost:5432/scod_db

# Optional integrations
FAST2SMS_API_KEY=
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_PHONE_NUMBER=
GOOGLE_SERVICE_ACCOUNT_EMAIL=
GOOGLE_PRIVATE_KEY=
```

### 4. Shopify Partner Dashboard Setup

1. Go to [partners.shopify.com](https://partners.shopify.com)
2. **Apps → Create app → Create app manually**
3. Fill in:
   - App name: `Smart COD Checkout Pro`
   - App URL: `https://your-app-domain.fly.dev`
   - Redirect URLs: `https://your-app-domain.fly.dev/auth/callback`
4. Copy **API key** and **API secret** → paste into `.env`
5. Under **App setup → GDPR webhooks**, set:
   - Customer data request: `https://your-app-domain.fly.dev/webhooks/gdpr`
   - Customer data erasure: `https://your-app-domain.fly.dev/webhooks/gdpr`
   - Shop data erasure: `https://your-app-domain.fly.dev/webhooks/gdpr`

### 5. Database Setup

```bash
# Create database
createdb scod_db

# Run Prisma migrations
npx prisma migrate dev --name init
npx prisma generate
```

### 6. Link App Config

```bash
shopify app config link
```

Select your app from the Shopify Partner Dashboard.

### 7. Run in Development

```bash
shopify app dev
```

This will:
- Start the Remix server on localhost:3000
- Open a ngrok tunnel for Shopify webhooks
- Print the installation URL for your dev store

---

## 🚢 Deployment Guide

### Option A: Fly.io (Recommended)

```bash
# Install Fly CLI
brew install flyctl   # macOS
# or: curl -L https://fly.io/install.sh | sh

# Login
fly auth login

# Launch app (first time)
fly launch

# Set secrets
fly secrets set SHOPIFY_API_KEY=xxx SHOPIFY_API_SECRET=xxx DATABASE_URL=xxx SHOPIFY_APP_URL=https://your-app.fly.dev

# Create PostgreSQL database
fly postgres create --name scod-db
fly postgres attach scod-db

# Deploy
fly deploy

# Run migrations
fly ssh console -C "npx prisma migrate deploy"
```

### Option B: Railway

```bash
# Install Railway CLI
npm i -g @railway/cli
railway login

# Create project
railway init

# Add PostgreSQL
railway add postgresql

# Deploy
railway up

# Set environment variables in Railway dashboard
# Run migrations
railway run npx prisma migrate deploy
```

### Option C: Docker

```bash
# Build and run locally
docker-compose up --build

# In production, set environment variables and run:
docker build -t scod-app .
docker run -p 3000:3000 --env-file .env scod-app
```

---

## 🧪 Testing Guide

### 1. Install on Development Store

1. Create a [Shopify Partner development store](https://partners.shopify.com/stores/new)
2. Run `shopify app dev` and copy the install URL
3. Install on your dev store

### 2. Test the Storefront Widget

1. In your Shopify admin → **Online Store → Themes → Customize**
2. Find **App embeds** → Enable **Smart COD Checkout Pro**
3. Visit a product page — you should see the COD button
4. Click it → COD form popup should appear
5. Fill the form → Submit → Check **SCOD Admin → Orders**

### 3. Test OTP Verification

1. Go to **Settings → SMS/OTP** → Enable OTP
2. Add your Fast2SMS API key
3. Submit a form with your phone number
4. Verify the 6-digit OTP received

### 4. Test Fake Order Detection

Submit with these numbers (should be flagged):
- `9999999999`, `1111111111`, `0000000000`
- Same phone 4+ times in an hour

### 5. Test Pixels

1. Install [Facebook Pixel Helper Chrome extension](https://chrome.google.com/webstore/detail/facebook-pixel-helper)
2. Add your Pixel ID in **Settings → Pixels**
3. Submit a COD order → Pixel Helper should show `Purchase` event

### 6. Test Shopify Order Sync

After submitting a COD order:
1. Go to Shopify Admin → **Orders**
2. A new order with payment status "Pending" should appear
3. Tags: `cod`, `cod-form`
4. Notes: customer phone, UTM parameters

---

## 📊 Analytics & Reporting

The analytics dashboard (Admin → Analytics) shows:
- Total orders, revenue, conversion rate, average order value
- 7-day orders chart by status
- Revenue trend chart
- Top products by COD volume
- Fake order rate
- OTP verification rate

Export orders as CSV from **Admin → Orders → Export CSV**.

---

## 💰 Monetization Guide

### Pricing Strategy

| Plan | Price | Target | Features |
|---|---|---|---|
| Free | $0/mo | New stores | 1 form, 50 orders/mo |
| Basic | $9.99/mo | Growing stores | 5 forms, 500 orders/mo, OTP, pixels, analytics |
| Pro | $24.99/mo | Scaling brands | Unlimited, Google Sheets, custom CSS, white-label |

### Revenue Projections

| Stores | Avg Plan | MRR |
|---|---|---|
| 100 | Basic | $999 |
| 500 | Mix | $7,500 |
| 1,000 | Mix | $17,500 |
| 5,000 | Mix | $95,000 |

### Growth Strategy

1. **App Store listing** — Target keywords: "COD form", "cash on delivery", "COD checkout"
2. **India-first marketing** — 90% of COD orders are from India
3. **YouTube tutorials** — Show setup in 5 minutes
4. **Partner with Shopify agencies** in India
5. **Affiliate program** — 20% recurring commission

### Competitor Analysis

| App | Price | Rating | Weakness |
|---|---|---|---|
| CodForm | $14.99/mo | 4.2 | Limited customization |
| EasyCOD | $9.99/mo | 3.9 | No analytics |
| COD King | $19.99/mo | 4.5 | Expensive |
| **SCOD Pro** | **$9.99/mo** | — | **More features, lower price** |

---

## 📱 App Store Submission Checklist

- [ ] App installs/uninstalls cleanly
- [ ] GDPR webhooks responding (customers/data_request, customers/redact, shop/redact)
- [ ] App proxy working (if used)
- [ ] Webhooks verified (HMAC validation)
- [ ] OAuth flow completes without errors
- [ ] App works in embedded mode (App Bridge)
- [ ] No external scripts on admin pages
- [ ] Privacy policy URL set
- [ ] Support email configured
- [ ] App listing: icon (1200x628), screenshots (3+), description
- [ ] Test on Firefox, Chrome, Safari
- [ ] Test on mobile (Shopify admin app)
- [ ] Billing API tested in dev store
- [ ] App review requirements: https://shopify.dev/docs/apps/launch/app-reviews

---

## 🔑 API Reference

### POST /api/cod-order

Creates a new COD order.

**Body:**
```json
{
  "shop": "mystore.myshopify.com",
  "formId": "clxyz...",
  "name": "Rajesh Kumar",
  "phone": "9876543210",
  "address": "123 Main Street, MG Road",
  "city": "Bengaluru",
  "state": "Karnataka",
  "pincode": "560001",
  "productId": "gid://shopify/Product/123",
  "productTitle": "Alcoclear Quit Alcohol",
  "variantId": "gid://shopify/ProductVariant/456",
  "quantity": 1,
  "productPrice": 599,
  "discountCode": "SAVE50"
}
```

**Response (OTP enabled):**
```json
{ "success": true, "requiresOtp": true, "orderId": "clxyz..." }
```

**Response (OTP disabled):**
```json
{ "success": true, "orderId": "clxyz...", "shopifyOrderId": "5678901234" }
```

### POST /api/verify-otp

Verifies OTP and confirms the order.

**Body:**
```json
{ "orderId": "clxyz...", "otp": "123456" }
```

### GET /api/form-config?shop=...&formId=...

Returns form configuration for the storefront widget.

---

## 🛡 Security

- All admin routes protected by Shopify OAuth session
- API routes validate `shop` domain against database
- Webhook signatures verified via HMAC-SHA256
- OTP codes expire after 10 minutes
- Rate limiting: 5 orders/hour per IP, 3 per phone
- Fake order detection: pattern matching + rate limits + blocklist
- CORS: `/api/*` routes allow only requests from `*.myshopify.com`

---

## 📞 Support

For questions about this codebase:
- Check `/docs/README.md` (this file)
- Review inline code comments
- Shopify docs: https://shopify.dev/docs/apps
- Remix docs: https://remix.run/docs

---

*Smart COD Checkout Pro — Built to compete with the best COD apps on the Shopify App Store*
